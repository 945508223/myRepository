create view RURAL_V_PROJCAPITAL as
select mm."YEAR",
       mm."ADMDIV",
       mm."MOF_DIV_CODE",
       mm."PROTYPE_ID",
       mm."BGT_DOC_TITLE",
       mm."BGT_DEC",
       mm."COR_BGT_DOC_NO",
       mm."DOC_DATE",
       mm."INDI_ID",
       mm."INDI_DETAILID",
       mm."AMOUNT",
       mm."PROJ_ID",
       mm."GUID",
       mm.projtypecode,
       mm.projtypename,
       mm.BUDGET_LEVEL_CODE,
       mm.budget_level_name,
       c.procode,
       c.proname
  from (select a.year,
               a.admdiv,
               a.mof_div_code,
               b.protype_id, -- 指标资金大类
               b.bgt_doc_title,
               b.bgt_dec,
               b.cor_bgt_doc_no,
               b.doc_date,
               b.indi_id, -- 指标id
               b.indi_detailid, -- 指标明细id
               a.amount,  --指标挂接金额
               a.proj_id, --项目id
               a.guid,
               (select itemcode
                  from ELE_FUNDCLASS
                 where guid = b.protype_id
                   and rownum = 1) as projtypecode,
               (select itemname
                  from ELE_FUNDCLASS
                 where guid = b.protype_id
                   and rownum = 1) as projtypename,
               b.BUDGET_LEVEL_CODE,
               (select itemname
                  from DM_BASE_CODES
                 where basetype = 'BUDGET_LEVEL'
                   and itemcode = b. BUDGET_LEVEL_CODE) as budget_level_name
          from RURAL_PROJECT_CAPITAL a
         inner join RURAL_V_INDIDETAIL b
            on a.year = b.year
           and a.indi_id = b.indi_id
           and a.indi_detailid = b.indi_detailid) mm
 inner join RURAL_PROJECT_INFO c
    on mm.year = c.year
   and mm.proj_id = c.guid
/

