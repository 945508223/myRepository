create view RURAL_V_PROJADMDIVNUM as
with fw_admindiv as(
select n.year,n.GUID,n.ITEMCODE ,n.ITEMNAME,n.ENDFLAG,n.SUPERGUID from fw_t_admindiv n where endflag='1'
),
proj_agency   as (
--纳入部门个数及项目录入个数，按年度+区划
select b.year,b.admdiv,count(distinct b.agency_id) as agencynum，count(1) as projnum from rural_project_info b  group by b.year,b.admdiv),

proj_pipei as (
--已匹配资金项目数，按年度+区划
select  m.year,m.admdiv,count(distinct m.proj_id) as projpipeinum  from RURAL_PROJECT_CAPITAL m group by m.year,m.admdiv),

proj_setp as (
--审核流程统计，按年度+区划
select  year,
       admdiv,
       nvl(sum(xjbm_projnum), 0) as xjbm_projnum,
       nvl(sum(xjcz_projnum), 0) as xjcz_projnum,
       nvl(sum(sjcz_projnum), 0) as sjcz_projnum,
       nvl(sum(gjbm_projnum), 0) as gjbm_projnum,
       nvl(sum(gjxczx_projnum), 0) as gjxczx_projnum,
       nvl(sum(gjcz_projnum), 0) as gjcz_projnum
  from (select a.year,
               a.recadmdiv as admdiv,
               a.stepid,
               a.stepname,
               a.stepstatus,
               count(distinct a.projguid) as projsetpnum
          from WF_STEPS a
         where a.stepstatus = '2'
         group by a.year, a.recadmdiv, a.stepid, a.stepname, a.stepstatus) pivot(sum(projsetpnum) as projnum for stepname in('县级主管部门终审' as xjbm,
                                                                                                                             '县级财政匹配资金及复核' as xjcz,
                                                                                                                             '市级财政资金匹配复核' as sjcz,
                                                                                                                             '省级主管部门复核' as gjbm,
                                                                                                                             '省级乡村振兴部门复核' as gjxczx,
                                                                                                                             '省级主管部门复核' as gjcz))
   group by year,admdiv )


select distinct fw.year,
       fw.guid as admdiv,
       fw.itemcode as admdiv_code,
       fw.itemname as admdiv_name,
       fw.SUPERGUID,
       fw.endflag,
       --纳入部门个数
       nvl(mm.agencynum, 0) as agencynum,
       --项目录入个数
       nvl(mm.projnum, 0) as projnum,
       --已匹配资金项目数
       nvl(nn.projpipeinum, 0) as projpipeinum,
       --县级主管部门终审
       nvl(oo.xjbm_projnum, 0) as xjbm_projnum,
       --县级财政匹配资金及复核
       nvl(oo.xjcz_projnum, 0) as xjcz_projnum,
       --市级财政资金匹配复核
       nvl(oo.sjcz_projnum, 0) as sjcz_projnum,
       --省级主管部门复核
       nvl(oo.gjbm_projnum, 0) as gjbm_projnum,
       --省级乡村振兴部门复核
       nvl(oo.gjxczx_projnum, 0) as gjxczx_projnum,
       --省级财政资金匹配复核
       nvl(oo.gjcz_projnum, 0) as gjcz_projnum
  from fw_admindiv fw
  left join proj_agency mm
    on fw.year = mm.year
   and fw.guid = mm.admdiv
  left join proj_pipei nn
    on fw.year = nn.year
   and fw.guid = nn.admdiv
  left join proj_setp oo
    on fw.year = oo.year
   and fw.guid = oo.admdiv
/

