create materialized view TASK_V_R1_REPORTTOTAL2021
    refresh force on demand
as
with admdiv as (
select a.TASKADMDIV,a.TASKADMDIVCODE,a.TASKADMDIVNAME,a.TASKID,a.SUPERTASKID,a.endflag,a.TASKMONTH
from RURAL_V_TASKDETAIL   a
),
--县级年初预算数，决算数等
 zj1 as (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.bamount) as  ncys ,sum(t.adamount) as bdys,sum(t.balance) as snjz,sum(t.finalamount) as ysjs
 from TASK_V_R1_REPORTDATAS t
 where  t.fundlevel='6' and fundname like '01%'
 group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
),
--0105 各级（不包括市级）衔接资金年初预算部分
zj2 as (
select supertaskid,taskid,taskadmdivcode,taskadmdivname,
nvl(sum(zy_ncys),0) as zy_ncys,
nvl(sum(gj_ncys),0) as gj_ncys,
nvl(sum(sj_ncys),0) as sj_ncys,
nvl(sum(xj_ncys),0) as xj_ncys
 from (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.fundlevel ,sum(t.bamount) as  ncys   from TASK_V_R1_REPORTDATAS t where  fundname='0105'  group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.fundlevel
 )
pivot(sum(ncys) as ncys  for  fundlevel in ('1' as zy,'2' as gj,'5' as sj,'6' as xj) )
group by supertaskid,taskid,taskadmdivcode,taskadmdivname
),
--0105 各级衔接资金--变动预算
zj6 as (
select supertaskid,taskid,taskadmdivcode,taskadmdivname,nvl(sum(bdys0105),0) as bdys0105
 from (
    select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.adamount) as  bdys0105
    from TASK_V_R1_REPORTDATAS t
    where  fundname='0105'
    group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
)
group by supertaskid,taskid,taskadmdivcode,taskadmdivname
),
--0105 各级衔接资金--农林水
zj7 as (
select supertaskid,taskid,taskadmdivcode,taskadmdivname,nvl(sum(bdys01),0) as bdys01
 from (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname ,sum(t.adamount) as  bdys01
 from TASK_V_R1_REPORTDATAS t
 where  fundname like '01%'
  group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
 )
group by supertaskid,taskid,taskadmdivcode,taskadmdivname
),
--县级年初预算明细数
zj4 as (
  select supertaskid,taskid,taskadmdivcode,taskadmdivname,
          nvl(sum(n0101_ncys),0) as n0101_ncys,
          nvl(sum(n0102_ncys),0) as n0102_ncys,
          nvl(sum(n0103_ncys),0) as n0103_ncys,
          nvl(sum(n0104_ncys),0) as n0104_ncys,
          nvl(sum(n0105_ncys),0) as n0105_ncys,
          nvl(sum(n0106_ncys),0) as n0106_ncys,
          nvl(sum(n0107_ncys),0) as n0107_ncys,
          nvl(sum(n0108_ncys),0) as n0108_ncys,
          nvl(sum(n0109_ncys),0) as n0109_ncys
    from (
          select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.fundname ,t.fundcn,sum(t.bamount) as  ncys
           from TASK_V_R1_REPORTDATAS t where  fundname like '01%'  and  t.fundlevel='6'
           group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.fundname,t.fundcn
           )
    pivot(sum(ncys) as ncys  for  fundname in ('0101' as n0101,'0102' as n0102,'0103' as n0103,'0104' as n0104,'0105' as n0105,'0106' as n0106,'0107' as n0107,'0108' as n0108,'0109' as n0109) )
    group by supertaskid,taskid,taskadmdivcode,taskadmdivname

),
--支出数据
zj3 as (
select supertaskid,taskid,taskadmdivcode,taskadmdivname,
nvl(sum(a21301_zc),0) as a21301,
nvl(sum(a21302_zc),0) as a21302,
nvl(sum(a21303_zc),0) as a21303,
nvl(sum(a21305_zc),0) as a21305,
nvl(sum(a21307_zc),0) as a21307,
nvl(sum(a21308_zc),0) as a21308,
nvl(sum(a21309_zc),0) as a21309,
nvl(sum(a21399_zc),0) as a21399,
nvl(sum(a201_zc),0) as a201,
nvl(sum(a205_zc),0) as a205,
nvl(sum(a206_zc),0) as a206,
nvl(sum(a207_zc),0) as a207,
nvl(sum(a208_zc),0) as a208,
nvl(sum(a210_zc),0) as a210,
nvl(sum(a211_zc),0) as a211,
nvl(sum(a212_zc),0) as a212,
nvl(sum(a214_zc),0) as a214,
nvl(sum(a215_zc),0) as a215,
nvl(sum(a216_zc),0) as a216,
nvl(sum(a217_zc),0) as a217,
nvl(sum(a220_zc),0) as a220,
nvl(sum(a221_zc),0) as a221,
nvl(sum(a222_zc),0) as a222,
nvl(sum(a224_zc),0) as a224,
nvl(sum(a229_zc),0) as a229
 from (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.payitem,t.payitmename,sum(t.amount) as amount
 from TASK_V_R1_REPORTDATAS t
 where /*t.fundlevel='6' and*/ fundname like '01%'  and t.payitem is not null or t.payitem <> ''
  group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.payitem,t.payitmename
)
pivot(sum(amount) as zc  for  payitem in( '21301' as a21301,'21302' as a21302,'21303' as a21303,'21305' as a21305,'21307' as a21307,'21308' as a21308,'21309' as a21309,'21399' as a21399 ,
        '201' as  a201,'205' as a205,'206' as a206, '207' as a207,'208' as a208,'210' as a210,'211' as a211, '212' as a212,'214' as a214,'215' as a215,'216' as a216,'217' as a217,
        '220' as a220,'221' as a221,'222' as a222,'224' as a224, '229' as a229  ) )
group by supertaskid,taskid,taskadmdivcode,taskadmdivname
)


select '2021' as year, aa.supertaskid,aa.taskid,aa.taskadmdivcode,aa.taskadmdivname,aa.endflag,aa.TASKMONTH,
--2020年决算数
mm.ysjs,
--年初预算
mm.ncys,
--其中年初预算衔接资金，中央 省级 市级 县级
nn.zy_ncys,nn.gj_ncys,nn.sj_ncys,nn.xj_ncys,
--上年结转
mm.snjz,
--变动预算
mm.bdys,
--各级衔接资金变动预算
oo.bdys0105,
--各级农林水变动预算
pp.bdys01,
--合计
round((a21301+a21302+a21303+a21305+a21307+a21308+a21309+a21399+a201+a205+a206+a207+a208+a210+a211+a214+a215+a216+a217+a220+a221+a224+a229),0)  as amount_hj,
--小计
round((a21301+a21302+a21303+a21305+a21307+a21308+a21309+a21399),0) as a213,
round(kk.a21301,0) as a21301,
round(kk.a21302,0) as a21302,
round(kk.a21303,0) as a21303,
round(kk.a21305,0) as a21305,
round(kk.a21307,0) as a21307,
round(kk.a21308,0) as a21308,
round(kk.a21309,0) as a21309,
round(kk.a21399,0) as a21399,
--sum(a21301_zc)+sum(a21302_zc)+sum(a21303_zc)+sum(a21305_zc)+sum(a21307_zc)+sum(a21308_zc)+sum(a21309_zc)+sum(a21399_zc) as a213,
round(kk.a201,0) as a201,
round(kk.a205,0) as a205,
round(kk.a206,0) as a206,
round(kk.a207,0) as a207,
round(kk.a208,0) as a208,
round(kk.a210,0) as a210,
round(kk.a211,0) as a211,
round(kk.a212,0) as a212,
round(kk.a214,0) as a214,
round(kk.a215,0) as a215,
round(kk.a216,0) as a216,
round(kk.a217,0) as a217,
round(kk.a220,0) as a220,
round(kk.a221,0) as a221,
round(kk.a222,0) as a222,
round(kk.a224,0) as a224,
round(kk.a229,0) as a229,
round(qq.n0101_ncys) as n0101_ncys,
round(qq.n0102_ncys) as n0102_ncys,
round(qq.n0103_ncys) as n0103_ncys,
round(qq.n0104_ncys) as n0104_ncys,
round(qq.n0105_ncys) as n0105_ncys,
round(qq.n0106_ncys) as n0106_ncys,
round(qq.n0107_ncys) as n0107_ncys,
round(qq.n0108_ncys) as n0108_ncys,
round(qq.n0109_ncys) as n0109_ncys

from  admdiv aa
left join  zj1 mm
on   aa.supertaskid= mm.supertaskid
and  aa.taskid=mm.taskid
and  aa.taskadmdivcode=mm.taskadmdivcode
and  aa.taskadmdivname=mm.taskadmdivname
left join zj2 nn
on   aa.supertaskid= nn.supertaskid
and  aa.taskid=nn.taskid
and   aa.taskadmdivcode=nn.taskadmdivcode
and   aa.taskadmdivname=nn.taskadmdivname
left join zj6 oo
on   aa.supertaskid= oo.supertaskid
and  aa.taskid=oo.taskid
and   aa.taskadmdivcode=oo.taskadmdivcode
and   aa.taskadmdivname=oo.taskadmdivname
left join zj7 pp
on   aa.supertaskid= pp.supertaskid
and  aa.taskid=pp.taskid
and   aa.taskadmdivcode=pp.taskadmdivcode
and   aa.taskadmdivname=pp.taskadmdivname
left join zj3 kk
on    aa.supertaskid= kk.supertaskid
and   aa.taskid=kk.taskid
and   aa.taskadmdivcode=kk.taskadmdivcode
and   aa.taskadmdivname=kk.taskadmdivname
left join zj4 qq
on    aa.supertaskid= qq.supertaskid
and   aa.taskid=qq.taskid
and   aa.taskadmdivcode=qq.taskadmdivcode
and   aa.taskadmdivname=qq.taskadmdivname
/

