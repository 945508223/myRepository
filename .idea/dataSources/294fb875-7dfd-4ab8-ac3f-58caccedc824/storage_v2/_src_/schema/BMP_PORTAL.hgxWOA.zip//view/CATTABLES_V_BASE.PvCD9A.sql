create view CATTABLES_V_BASE as
(
SELECT T1.CATCODE GUID,
       T1.CATNAME AS NAME,
       NULL AS TABLETYPE,
       '#' AS PID,
       '0' AS nodetype,
       to_number(CATCODE) as orderno
  from dm_base_category T1
 where UPPER(T1.appid) = 'BMP'
   and UPPER(t1.businessType) = 'BASE'
UNION ALL
SELECT T2.TABLE_NAME GUID,
       T2.TABLE_NAMECN AS NAME,
       T2.TABLETYPE,
       T2.CATCODE AS PID,
       '1' AS nodetype,
       orderno
  from dm_df_tables T2
 WHERE UPPER(T2.appid) = 'BMP'
   AND UPPER(T2.BUSINESSTYPE) = 'BASE'
   AND t2.objecttype = '0'
)
/

