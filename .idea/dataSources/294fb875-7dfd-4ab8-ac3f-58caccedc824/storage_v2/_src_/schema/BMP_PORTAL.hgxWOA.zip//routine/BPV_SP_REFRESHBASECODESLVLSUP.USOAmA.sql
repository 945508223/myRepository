create procedure BPV_SP_refreshbasecodeslvlsup(v_basetype  varchar2,
                                                 v_superguid varchar2) AS
  v_sql           varchar2(4000);
  v_ordernum      varchar2(60);
  v_superOrdernum varchar2(60);
  v_guid          varchar2(32);
  v_i             number;
  v_count         number;
  type cur IS ref CURSOR;
  v_query cur;
BEGIN
  IF v_superguid IS NULL THEN
    RETURN;
  END IF;
  IF v_superguid = '#' THEN
    v_superOrdernum := '';
  ELSE
    SELECT ordernum
      INTO v_superOrdernum
      FROM dm_base_codes
     WHERE guid = v_superguid
       AND basetype = v_basetype;
    v_count := 0;
    SELECT count(1)
      INTO v_count
      FROM dm_base_codes
     WHERE superguid = v_superguid
       AND basetype = v_basetype;
    IF v_count > 0 THEN
      UPDATE dm_base_codes
         SET endflag = '0'
       WHERE guid = v_superguid
         AND basetype = v_basetype;
      BPV_SP_refreshbasecodeslvl(v_basetype, v_guid);
    ELSE
      UPDATE dm_base_codes
         SET endflag = '1'
       WHERE guid = v_superguid
         AND basetype = v_basetype;
    END IF;
  END IF;
  v_i := 0;
  OPEN v_query FOR
    SELECT guid
      FROM dm_base_codes
     WHERE superguid = v_superguid
       AND basetype = v_basetype
     ORDER BY orderno;
  LOOP
    FETCH v_query
      INTO v_guid;
    EXIT WHEN v_query % notfound;
    v_i        := v_i + 1;
    v_ordernum := (v_superOrdernum || lpad(v_i, 4, '0'));
    v_count    := 0;
    SELECT count(1)
      INTO v_count
      FROM dm_base_codes
     WHERE superguid = v_guid
       AND basetype = v_basetype;
    IF v_count > 0 THEN
      UPDATE dm_base_codes
         SET ordernum = v_ordernum, endflag = '0'
       WHERE guid = v_guid
         AND basetype = v_basetype;
      BPV_SP_refreshbasecodeslvl(v_basetype, v_guid);
    ELSE
      UPDATE dm_base_codes
         SET ordernum = v_ordernum, endflag = '1'
       WHERE guid = v_guid
         AND basetype = v_basetype;
    END IF;
  END LOOP;
  CLOSE v_query;
END;

/

