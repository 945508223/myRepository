create view RURAL_V_TASKDETAIL as
select n.TASKNO,
       n.TASKMONTH,
       n.TASKTYPE,
       n.ADMDIV,
       n.ADMDIVCODE,
       n.ADMDIVNAME,
       N.STARTDATE,
       N.ENDDATE,
       n.SUPERTASKID,
       n.TASKID,
       n.TASKNAME,
       n.TASKSHOWNAME,
       n.TASKADMDIV,
       n.TASKADMDIVCODE,
       n.TASKADMDIVNAME,
       t.superguid      as superadmdiv,
       t.endflag        as endflag,
       t.FINADMLEVELCODE as budgetlevel,
       n.TASKSTATUS,
       n.TASKUPDATE, --上报时间
       N.TASKDOWNDATE,
       n.CHECKSTATUS,
       n.SUBUSER,      --填报人
       n.SUBDEPTMANAGER,    --科室负责人
       n.SUBMANAGER,   --单位负责人
       n.SUBADMDIVNAME,  --填报单位
       n.SUBDEPARTMENT   --填报科室
  from (SELECT B.TASKNO,
               A.TASKMONTH,
               A.TASKTYPE,
               A.ADMDIV,
               A.MOF_DIV_CODE AS ADMDIVCODE,
               A.MOF_DIV_NAME AS ADMDIVNAME,
               A.STARTDATE,
               A.ENDDATE,
               B.SUPERTASKID,
               B.GUID AS TASKID,
               A.TASKNAME,
               A.TASKNAME || '[' || nvl((select itemname
                                          from dm_base_codes
                                         where basetype = 'TASKSTATUS'
                                           and itemcode = B.TASKSTATUS),
                                        '未下达') || ']' AS TASKSHOWNAME,
               B.TASKADMDIV,
               B.TASKADMDIVCODE,
               B.TASKADMDIVNAME,
               B.TASKSTATUS,
               B.TASKUPDATE,
               B.TASKDOWNDATE,
               B.CHECKSTATUS,
               B.SUBUSER,      --填报人
               B.SUBDEPTMANAGER,    --科室负责人
               B.SUBMANAGER,   --单位负责人
               B.SUBADMDIVNAME,  --填报单位
               B.SUBDEPARTMENT   --填报科室
          FROM RURAL_TASK_INFO A
         RIGHT JOIN RURAL_TASK_DETAIL B
            ON A.GUID = B.SUPERTASKID) n
  left join fw_t_admindiv t
    on n.taskadmdiv = t.GUID
/

