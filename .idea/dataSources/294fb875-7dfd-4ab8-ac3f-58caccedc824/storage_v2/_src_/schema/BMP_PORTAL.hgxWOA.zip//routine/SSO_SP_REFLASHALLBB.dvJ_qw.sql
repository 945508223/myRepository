create procedure sso_sp_reflashAllBB(v_tablename varchar2) as
  v_count    number;
  v_sql      varchar2(4000);
  v_sql1      varchar2(4000);
  V_COLUMN_NAME    varchar2(4000);
  v_sql_PRO      varchar2(4000);
  type cur is ref cursor;
  cursors cur; 
  v_pro cur;
begin
  v_count := 0;
  v_sql_PRO:='select t.itemcode from ELE_FUNDCLASS t where  t.year = to_char(sysdate,''yyyy'')';
  v_sql   := 'select a.COLUMN_NAME
  from user_tab_columns a
 where a.TABLE_NAME = upper(''rural_v_inditalamtzz'')
   and a.DATA_TYPE =''NUMBER''';
--ELE_FUNDCLASS
 /* open v_pro for v_sql_PRO;
    loop
      fetch v_pro
        into V_procode;
      exit when v_pro%notfound;*/


          open cursors for v_sql;
          loop
            fetch cursors
              into V_COLUMN_NAME;
            exit when cursors%notfound;
         v_sql1  :=   'insert into DM_BASE_reflashAllBB  select *  from (select a.year,a.admdiv,a.admdiv_code,projtypecode, '||V_COLUMN_NAME||'
                  from rural_v_inditalamtzz a) pivot(sum('||V_COLUMN_NAME||') for projtypecode in(''001'' as  '||V_COLUMN_NAME||'_001,
                  ''002'' as  '||V_COLUMN_NAME||'_002,''003'' as  '||V_COLUMN_NAME||'_003,''004'' as  '||V_COLUMN_NAME||'_004,''005'' as  '||V_COLUMN_NAME||'_005,
                  ''006'' as  '||V_COLUMN_NAME||'_006,''007'' as  '||V_COLUMN_NAME||'_007,''008'' as  '||V_COLUMN_NAME||'_008,
                  ''009'' as  '||V_COLUMN_NAME||'_009,''010'' as  '||V_COLUMN_NAME||'_010));';

            

          end loop;
          close cursors;

     /* end loop;
      close v_pro;*/
end sso_sp_reflashAllBB;
/

