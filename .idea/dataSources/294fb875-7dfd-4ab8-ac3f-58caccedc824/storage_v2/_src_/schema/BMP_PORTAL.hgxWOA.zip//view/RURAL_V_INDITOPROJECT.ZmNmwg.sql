create view RURAL_V_INDITOPROJECT as
with project_info as
--指标挂接表
 (select u.year,
         u.admdiv,
         u.mof_div_code,
         u.indi_id,
         u.protype_id,
         u.BUDGET_LEVEL_CODE,
         sum(u.amount) as amount
    from RURAL_V_PROJCAPITAL u
   group by u.year,
            u.admdiv,
            u.mof_div_code,
            u.indi_id,
            u.protype_id,
            BUDGET_LEVEL_CODE)

select nn.year,
       (select guid from fw_t_admindiv where itemcode = nn.mof_div_code) as admdiv,
       nn.mof_div_code,
       nn.protype_id,
       nn.budget_level_code,
       (select itemcode from ELE_FUNDCLASS where guid=nn.protype_id and rownum=1) as projtypecode,
       (select itemname from ELE_FUNDCLASS where guid=nn.protype_id and rownum=1) as projtypename,
       (select  itemname from DM_BASE_CODES t where basetype='BUDGET_LEVEL' and itemcode = nn. BUDGET_LEVEL_CODE ) as budget_level_name,
       nn.amount
  from (
        --县级
        select a.year,
                a.mof_div_code,
                a.protype_id,
                a.BUDGET_LEVEL_CODE,
                sum(amount) as amount
          from project_info a
         group by a.year, a.mof_div_code, a.protype_id, a.BUDGET_LEVEL_CODE
        union all
        --市级
        select a.year,
               substr(a.mof_div_code, 1, 4) as mof_div_code,
               a.protype_id,
               a.BUDGET_LEVEL_CODE,
               sum(amount) as amount
          from project_info a
         group by a.year,
                  substr(a.mof_div_code, 1, 4),
                  a.protype_id,
                  a.BUDGET_LEVEL_CODE
        --省级
        union all
        select a.year,
               substr(a.mof_div_code, 1, 2) as mof_div_code,
               a.protype_id,
               a.BUDGET_LEVEL_CODE,
               sum(a.amount) as amount
          from project_info a
         group by a.year,
                  substr(a.mof_div_code, 1, 2),
                  a.protype_id,
                  a.BUDGET_LEVEL_CODE) nn
/

