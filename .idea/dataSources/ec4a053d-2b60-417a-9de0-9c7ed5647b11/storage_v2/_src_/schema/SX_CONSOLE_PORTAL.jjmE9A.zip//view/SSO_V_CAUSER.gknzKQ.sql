create view SSO_V_CAUSER as
with admdiv as(
 select   a.YEAR,a.ITEMCODE,a.ITEMNAME,a.GUID,a.ADMDIV,a.SHOWNAME,a.mof_div_type,a.superguid,a.FINADMLEVELCODE   from sso_v_pubadmdiv a
),
--单位表
 agency as(
 select  a.YEAR,a.ITEMCODE,a.ITEMNAME,a.GUID,a.ADMDIV   from  sso_v_pubagency a
),
--处室表

 department as(
 select  a.YEAR,a.ITEMCODE,a.ITEMNAME,a.GUID,a.ADMDIV,a.SUPERGUID,a.admdivcode   from sso_v_pubdepartment a
)

--系统内部用户
SELECT  a.guid,
       --用户登录code
        a.code,
       --用户登录名称
        a.name,
        --年度
        b.year  as year,
        --行政区划id
        a.admdiv,
        --管理单位id，如果为财政用户取区划id
        a.agencyid as agency,
        --用户密码
        a.password as LogPassWord,
        --用户所在处室id
        a.division,
        --用户类别
        a.UserType,
        --是否数据管理员
        a.isdataadmin,
        --用户状态
        a.status,
        --用户所在区划code
        b.itemcode as admdivcode,
        --用户所管辖单位，如果财政本级用户则取上级id

        case when length(a.province)<>9 and  a.UserType=1  and substr(a.province,length(a.province)-1,2) ='00' then  b.superguid
          when  length(a.province)= 9 and a.UserType=1 then b.superguid
           else  a.upagencyid
             end  as upagencyid ,
        --用户管辖单位名称，财政用户不处理了，只取单位用户单位名称
        (select ITEMNAME from  agency  where  guid = a.upagencyid  and admdiv= a.admdiv and rownum=1 ) as upagencyname,
         --用户所管辖区划，如财政用户 财政本级用户则取上级id ，单位用户取自己
        case when   upadmdiv is not null or upadmdiv <> '' then  upadmdiv
          when length(a.province)<>9 and  substr(a.province,length(a.province)-1,2) ='00' and ( upadmdiv is null or upadmdiv='' ) then  b.superguid
            when  length(a.province)= 9  then b.superguid
              else  a.admdiv
                end  as upadmdiv ,
         --用户所在区划级次
          b.finadmlevelcode as admdivlevel,
     --   ( select  finadmlevelcode  from fw_t_admindiv where  guid= a.admdiv and rownum=1) as admdivlevel,
         --用户所在区划名称
         b.itemname as admdivname,
         --    (select itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivname,
         --用户所在区划编码+名称
         b.itemcode||'-'||b.itemname as admdivshowname,
         --用户所在单位名称,财政用户取区划名称，单位用户取单位名称
         case when a.usertype='1' then b.itemcode else c.itemcode end as agencycode,
         case when a.usertype='1' then b.itemname else c.itemname end as agencyname,
         case when a.usertype='1' then b.itemcode||'-'||b.itemname else  c.itemcode||'-'|| c.itemname end as agencyshowname,
         --用户所在处室名称，财政用户取取数，单位用户取单位
         case when a.usertype='1' then d.itemcode else c.itemcode end as divisioncode,
         case when a.usertype='1' then d.itemname else c.itemname end as divisionname,
         --上级单位名称
         case when a.usertype='1' then d.itemname else c.itemname end as UPDIVIDNAME,
       /* (select '['||itemcode||']'||itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivshowname,
        (select itemname  from sso_v_admdivagency where guid=a.agencyid and rownum=1) as agencyname,
        (select '['||itemcode||']'||itemname  from sso_v_admdivagency where guid=a.agencyid and rownum=1) as agencyshowname,
        (select '['||itemcode||']'||itemname  from sso_v_pubdepartment where guid=a.division and rownum=1) as divisionname,*/
        a.telno,
        a.wechatno,
        a.remark
  FROM  sso_t_userinfo a
  left join  admdiv b
  ON     A.ADMDIV = B.guid
  and    a.YEAR = b.year
  left join agency  c
  on   a.admdiv= c.admdiv
  and  a.agencyid = c.guid
  left join department d
  on   a.admdiv=d.admdiv
  and  a.division=d.guid
/*  union all
 --一体化用户表
 SELECT  distinct  a.guid,
        a.code,
        a.name,
        a.year,
        b.guid as admdiv,
        --财政用户用区划作为所在单位 2 省级 取到自己  3 计划单列市取自己  4 市级取自己   5 县级取上级节点
         case b.mof_div_type  when '2' then  b.guid  when '3' then  b.guid    when '4'  then b.guid  else  b.superguid  end as agency,
      --  a.guid  as agency,
        a.password as LogPassWord,
        c.guid as division,
        to_char(a.UserType) as UserType,
        '0' as isdataadmin,
        a.status,
        b.itemcode  as admdivcode,
        --取上级节点
       b.superguid as upagencyid,
       b.superguid as upadmdiv,
    --     (select superguid  from admdiv d where  d.ITEMCODE=a.admdiv  and rownum=1)  as upagencyid,
    --     (select superguid  from admdiv d where  d.ITEMCODE=a.admdiv  and rownum=1)  as upadmdiv,
         b.mof_div_type as admdivlevel,
         b.itemname,
         b.SHOWNAME as admdivshowname,
         b.itemcode as agencycode,
         b.itemname as agencyname,
         b.SHOWNAME as agencyshowname,
         c.itemcode as divisioncode,
         c.itemname as divisionname,
          --上级单位名称
         c.itemname as UPDIVIDNAME,
        '' as telno,
        '' as wechatno,
        a.remark
  FROM  fasp_t_causer  a --@portal a
 left join  admdiv  b
 ON     A.ADMDIV = B.ITEMCODE
 left join  department  c
  on     a.admdiv =c.admdivcode
  and    a.division = c.ITEMCODE
where    a.usertype='1'-- and a.code <> '14_sys_admin';*/
/

