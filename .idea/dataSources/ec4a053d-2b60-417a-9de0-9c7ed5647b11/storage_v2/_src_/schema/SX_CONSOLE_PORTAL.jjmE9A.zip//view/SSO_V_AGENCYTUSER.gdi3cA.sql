create view SSO_V_AGENCYTUSER as
select guid,
       '#' as superguid,
       itemcode,
       '[' || itemcode || ']' || itemname as itemname,
       levels,
       ordernum,
       endflag,
       admdiv,
       year,
       '1' as isdepartment,
       '' as ZW
  from sso_v_pubagency a
 where a.STATUS <> '2'  AND ADMDIV <> '****' --新增AND ADMDIV <> '****'
 --新增  20210508
union
select guid,
       agencyid as superguid,
       a.code as itemcode,
       a.name as itemname,
       4 as levels,
       '0' as ordernum,
       '1' as endflag,
       admdiv,
       '****' AS year,
       '0' as isdepartment,
       REMARK  AS ZW
  from sso_t_userinfo a
 where a.usertype in ('2', '0')
   and exists (select guid
          from sso_v_pubagency b
         where b.GUID = a.agencyid
           and b.STATUS <> '2')
   and a.status <> '2'
/

