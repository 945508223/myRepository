create view SSO_V_ADMDIVAGENCY as
SELECT GUID,
       ITEMCODE,
       ITEMNAME,
       MOF_DIV_CODE,
       SUPERGUID,
       ENDFLAG,
       YEAR,
       ISLEAF,
       ISADMDIV, --是否区划标识
       ADMDIV,
       STATUS,
       LEVELS,
       ORDERNUM,
       ITEMCODE || '-' || ITEMNAME AS SHOWNAME,
       BUDGET_LEVEL, --区划级次
       DEPARTTYPE, --部门行业属性
       ISDEPARTMENT --是否部门标识
  FROM (
        --区划表
        SELECT GUID,
                ITEMCODE,
                ITEMNAME,
                ITEMCODE AS MOF_DIV_CODE,
                SUPERGUID,
                '0' AS ENDFLAG,
                YEAR,
                ENDFLAG AS ISLEAF,
                '1' AS ISADMDIV,
                GUID AS ADMDIV,
                '1' AS STATUS,
                0 LEVELS,
                ORDERNUM,
                FINADMLEVELCODE AS BUDGET_LEVEL,
                '' AS DEPARTTYPE,
                '0' AS ISDEPARTMENT
          FROM SSO_V_PUBADMDIV
        --单位表
        UNION ALL
        SELECT B.GUID,
               B.ITEMCODE,
               B.ITEMNAME,
               B.MOF_DIV_CODE,
               case when B.SUPERGUID='#' then b.ADMDIV else  B.SUPERGUID end as superguid,
               B.ENDFLAG,
               B.YEAR,
               B.ENDFLAG AS ISLEAF,
               '0' AS ISADMDIV,
               B.ADMDIV,
               B.STATUS,
               a.LEVELS+B.LEVELS as LEVELS ,
               B.ORDERNUM,
               A.FINADMLEVELCODE AS BUDGET_LEVEL,
               B.DEPARTTYPE,
               B.ISDEPARTMENT
          FROM SSO_V_PUBAGENCY B, SSO_V_PUBADMDIV A
         WHERE B.ADMDIV = A.GUID
           AND B.YEAR = A.YEAR)
/

