create view DM_BASE_APPS_VIEW as
select appid as guid ,projectname,'' AS ORDERNUM,'1' AS LEVELS, '#' AS SUPERGUID,appid AS ITEMCODE ,'1' AS ENDFLAG,appid, appname AS ITEMNAME, appurl, hostname, portnumber, servicename, dbuid, dbpwd, systype, versionno from dm_base_apps
/

