create view ESEARCH_V_POLLAWSTYPE as
select guid,lawclass as superguid,itemname||'['||itemcode||']' as name,divid , '0' as flag  from  ESEARCH_T_POL
union all
select guid, superguid  as superguid,itemname as name,'' divid ,'1' as flag  from  ESEARCH_T_LAWSTYPE
/

