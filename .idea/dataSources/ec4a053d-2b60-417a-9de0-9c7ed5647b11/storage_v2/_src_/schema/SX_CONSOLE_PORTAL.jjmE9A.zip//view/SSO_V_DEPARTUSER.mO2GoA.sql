create view SSO_V_DEPARTUSER as
select guid,
       superguid,
       itemcode,
       '[' || itemcode || ']' || itemname as itemname,
       levels,
       ordernum,
       endflag,
       --区划id
       admdiv,
       year,
       --是否处室
       '1' as isdepartment,
       --职务
       '' AS ZW
  from sso_v_pubdepartment
 WHERE STATUS <> '2' AND ADMDIV <> '****' --新增AND ADMDIV <> '****'
 --新增  20210508
 UNION ALL
select guid,
       division as superguid,
       a.code as itemcode,
       a.name as itemname,
       4 as levels,
       '0' as ordernum,
       '1' as endflag,
       admdiv,
       a.year AS year,
       '0' as isdepartment,
       REMARK as ZW
  from sso_v_causer a
 where a.usertype = '1'
   and a.status <> '2'
   and exists (select guid
          from sso_v_pubdepartment B
         where b.status <> '2'
           and a.division = b.guid)

/

