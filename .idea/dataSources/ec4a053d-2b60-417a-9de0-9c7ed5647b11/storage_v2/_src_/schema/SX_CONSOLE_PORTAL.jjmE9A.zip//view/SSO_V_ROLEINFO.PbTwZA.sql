create view SSO_V_ROLEINFO as
select YEAR,
       "GUID",
       "ROLECODE" as itemcode,
       "ROLENAME" as itemname,
       "ADMDIV",
       "AGENCY",
       "ROLETYPE",
       "STATUS",
        "ISSYS",
       "REMARK",
       "PROVINCE",
       --"ROLENATURE",
       '#' as superguid,
        (select '['||itemcode||']'||itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivname,
        (select '['||itemcode||']'||itemname  from sso_v_pubagency where guid=a.agency and rownum=1) as agencyname,
        A.is_pubrole,
        '' ROLENATURE
  from sso_t_roleinfo a
  union all
  --一体化角色表
select c.year,
       c.guid,
       c.code as itemcode,
       c.name as itemname,
       '****' as admdiv,
       '****' as agency,
       to_char(c.roletype),
       c.status,
       to_char(c.issys),
       c.remark,
       c.province,
       '#' as superguid,
       '' as admdivname,
       '' as agencyname,
       '1' as is_pubrole,
       '' as ROLENATURE
 --- from  fasp_t_carole@portal c
 from  fasp_t_carole c
  WHERE name LIKE '公用-三保%' or name like '公用-政府%'
/

