create view SSO_V_CAUSERROLE as
select  t.userguid,b.code,b.name,b.admdiv,b.agency as agencyid,t.roleguid,c.itemcode as rolecode,c.itemname as rolename
from
(select userguid,roleguid
 from sso_t_userrole
 union all
 select userguid,roleguid from fasp_t_causerrole
 --from fasp_t_causerrole@portal
 ) t
left join  sso_v_causer b
on t.userguid=b.guid
left join sso_v_roleinfo c
on t.roleguid = c.guid
/

