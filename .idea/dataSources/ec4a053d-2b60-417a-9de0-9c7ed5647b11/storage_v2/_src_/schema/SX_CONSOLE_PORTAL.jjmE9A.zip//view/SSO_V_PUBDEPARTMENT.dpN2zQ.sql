create view SSO_V_PUBDEPARTMENT as
select year,
       guid,
       code as itemcode,
       name as itemname,
       code||'-'||name as showname,
       levels,
       case
         when LEVELS = '1' then
          '#'
         else
          superguid
       end as superguid,
       endflag,
       admdiv,
       admdiv as admdivcode,
       ordernum,
   --   '0' as  Deptpriority,
       status,
       null as start_date,
       null as end_date,
       m.deptpriority --是否特殊处室
  from sso_t_pubdepartment m
--处室新表
  union all
  select a.fiscal_year as year,
         a.ele_id as guid,
         a.ele_code as itemcode,
         a.ele_name as itemname,
         a.ele_code||'-'||a.ele_name as showname,
         a.level_no as levels,
         a.parent_id as superguid,
         to_char(a.is_leaf) as endflag,
         b.mof_div_id as admdiv,
         a.mof_div_code as admdivcode,
         to_char(a.level_no) as ordernum,
         '1' as status,
         null start_date,
         null end_date,
        '0' as deptpriority
  --from ele_department@BASMOFDIV  a
 -- left join bas_mof_div@BASMOFDIV  b
   from ele_department  a
  left join bas_mof_div  b
   on  a.mof_div_code=b.mof_div_code
   and a.fiscal_year=b.year
  WHERE A.IS_DELETED='2'
  AND   B.IS_DELETED='2'
/

