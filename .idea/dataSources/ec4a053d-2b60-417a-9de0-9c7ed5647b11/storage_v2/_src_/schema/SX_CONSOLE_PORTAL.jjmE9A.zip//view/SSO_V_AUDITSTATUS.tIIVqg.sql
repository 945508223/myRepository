create view SSO_V_AUDITSTATUS as
select '1' as itemcode,'1' as guid,'审核中' as itemname, '1' as levels, '1' as endflag, '2' orderno, '00002' ordernum,'#' as superguid, '1' status from  dual
union all
select '2' as itemcode,'2' as guid,'申请通过' as itemname, '1' as levels, '1' as endflag, '3' orderno, '00003' ordernum,'#' as superguid, '1' status from  dual
union all
select '3' as itemcode,'3' as guid,'申请失败' as itemname, '1' as levels, '1' as endflag, '1' orderno, '00004' ordernum,'#' as superguid, '1' status from  dual
/

