create view SSO_V_USERPASSWORD as
select ss.guid,ss.code,ss.password,'' as putpassword,'' as newpassword,'' as confirmpassword from  SSO_T_USERINFO ss
/

