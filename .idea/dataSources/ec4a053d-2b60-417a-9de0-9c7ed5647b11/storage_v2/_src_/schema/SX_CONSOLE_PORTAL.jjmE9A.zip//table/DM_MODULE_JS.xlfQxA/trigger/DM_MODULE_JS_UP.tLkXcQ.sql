create trigger DM_MODULE_JS_UP
    before update
    on DM_MODULE_JS
    for each row
begin
  if updating('js_text') then
    insert into dm_module_js_bak
      (versionno, guid, itemcode, itemname, appid, bmgz, remark, js_text)
    values
      (to_char(systimestamp, 'yyyy-mm-dd hh24:mi:ss:ff'),
       :old.guid,
       :old.itemcode,
       :old.itemname,
       :old.appid,
       :old.bmgz,
       :old.remark,
       :old.js_text);
  end if;

end;


/

