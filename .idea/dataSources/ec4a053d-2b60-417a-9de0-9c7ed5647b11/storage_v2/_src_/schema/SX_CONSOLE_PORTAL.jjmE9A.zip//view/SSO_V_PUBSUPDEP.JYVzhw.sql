create view SSO_V_PUBSUPDEP as
SELECT ENDFLAG,
       SUPERGUID,
       LEVELS,
       ORDERNO,
       ORDERNUM,
       GUID,
       YEAR,
       ITEMCODE ,
       ITEMNAME,
       ADMDIV, --区划id
       STATUS,
       TEL,
       MOB,
       FAX,
       ZIP,
       REMARK,
       AGENCYLEVECODE,
       BGTTYPEFLAG,
       PAYTYPEFLAG,
       ISDEPARTMENT,  --是否部门标识
       DEPARTTYPE,    --部门行业分类
       MOF_DIV_CODE,  --区划编码
       AGENCY_ABBREVIATION,
       UNIFSOC_CRED_CODE,
       AGENCY_ADM_LEVEL_CODE,
       AGENCY_TYPE_CODE,
       AGENCY_LEADER_PER_NAME,
       AGENCY_ADD,
       IND_CODE,
       FUND_GUAR_CODE,
       MOF_DEP_CODE,
       SUPDEP_CODE,
       CAPITAL_TYPE,
       CREATE_TIME,
       CREATEUSERID,
       IS_ENABLED,  --是否启用
       START_DATE,
       END_DATE,
       UPDATE_TIME
  FROM SSO_V_PUBAGENCY  a
 WHERE  a.ISDEPARTMENT='1'
/

