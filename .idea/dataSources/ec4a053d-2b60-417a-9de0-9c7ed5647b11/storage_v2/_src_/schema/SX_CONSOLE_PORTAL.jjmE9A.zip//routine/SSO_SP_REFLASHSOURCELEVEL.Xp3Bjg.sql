create PROCEDURE SSO_sp_reflashSourceLevel(v_RelaTableName varchar2,v_syscode varchar2,v_busitype varchar2,v_SuperID varchar2)
AS
  v_SQL varchar2(8000);
  v_Cnt int;
  v_SuperLvlID varchar2(100);
BEGIN

  IF v_SuperID = 'root' or v_SuperID = '#' THEN
    v_SuperLvlID := '';
  ELSE
       v_SQL := 'SELECT Count(*) FROM '||v_RelaTableName||' WHERE sourceid = '''||v_SuperID||''' and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''' ' ;
    EXECUTE IMMEDIATE v_SQL INTO v_Cnt;
    IF v_Cnt <= 0 THEN
       RETURN;
    END IF;
       v_SQL := 'SELECT LevelID FROM '||v_RelaTableName||' WHERE sourceid = '''||v_SuperID||''' and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''' ' ;
    EXECUTE IMMEDIATE v_SQL INTO v_SuperLvlID;
  END IF;

  v_SQL := 'DECLARE' || chr(10);
  v_SQL := v_SQL || '    v_Index integer;' || chr(10);
  v_SQL := v_SQL || '    v_Cnt integer;' || chr(10);
  v_SQL := v_SQL || '    v_sourcecode varchar2(255);' || chr(10);
  v_SQL := v_SQL || '    v_sourceid varchar2(100);' || chr(10);
  v_SQL := v_SQL || '    v_BaseLvlID varchar2(100);' || chr(10);
  v_SQL := v_SQL || '    v_SubLvlID_Base varchar2(60);' || chr(10);
  v_SQL := v_SQL || 'BEGIN' || chr(10);
  v_SQL := v_SQL || '    SELECT Count(*) INTO v_Cnt FROM '||v_RelaTableName||' WHERE SuperID = '''||v_SuperID||'''  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '    IF v_Cnt <= 0 THEN' || chr(10);
  v_SQL := v_SQL || '      UPDATE '||v_RelaTableName||' set EndFlag = ''1'' WHERE sourceid = '''||v_SuperID||''' and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '      RETURN;' || chr(10);
  v_SQL := v_SQL || '    END IF;' || chr(10);
  v_SQL := v_SQL || '    v_Cnt := 0;' || chr(10);
  v_SQL := v_SQL || '    SELECT Count(*) INTO v_Cnt FROM '||v_RelaTableName||' WHERE sourceid = '''||v_SuperID||'''  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '    IF v_Cnt > 0 THEN' || chr(10);
  v_SQL := v_SQL || '      UPDATE '||v_RelaTableName||' set EndFlag = ''0'' WHERE sourceid = '''||v_SuperID||'''  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '    END IF;' || chr(10);
  v_SQL := v_SQL || '    v_BaseLvlID := '''||Nvl(v_SuperLvlID,'')||''';' || chr(10);
  v_SQL := v_SQL || '    v_Index := 0;' || chr(10);
  v_SQL := v_SQL || '    FOR C1 IN (SELECT sourcecode,sourceid,LevelID FROM '||v_RelaTableName||' WHERE SuperID = '''||v_SuperID||''' and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||'''  ORDER BY sourcecode) LOOP' || chr(10);
  v_SQL := v_SQL || '      v_Index := v_Index + 1;' || chr(10);
  v_SQL := v_SQL || '      v_SubLvlID_Base := v_BaseLvlID || lPad(TO_Char(v_Index),6,''0'');' || chr(10);
  v_SQL := v_SQL || '      IF Nvl(C1.LevelID,''$'') <> ''$'' AND Nvl(C1.LevelID,''$'') <> v_SubLvlID_Base THEN' || chr(10);
  v_SQL := v_SQL || '        UPDATE '||v_RelaTableName||' SET LevelID = ''A'' || SubStr(LevelID,2) WHERE ((sourceid = C1.sourceid) OR (LevelID <> C1.LevelID AND LevelID LIKE C1.LevelID || ''%''))  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '      END IF;' || chr(10);
  v_SQL := v_SQL || '    END LOOP;' || chr(10);
  v_SQL := v_SQL || '    v_BaseLvlID := '''||Nvl(v_SuperLvlID,'')||''';' || chr(10);
  v_SQL := v_SQL || '    v_Index := 0;' || chr(10);
  v_SQL := v_SQL || '    FOR C1 IN (SELECT sourcecode,sourceid,LevelID FROM '||v_RelaTableName||' WHERE SuperID = '''||v_SuperID||''' and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||'''  ORDER BY sourcecode) LOOP' || chr(10);
  v_SQL := v_SQL || '      v_sourceid := C1.sourceid;' || chr(10);
  v_SQL := v_SQL || '      v_sourcecode := C1.sourcecode;' || chr(10);
  v_SQL := v_SQL || '      v_Index := v_Index + 1;' || chr(10);
  v_SQL := v_SQL || '      v_SubLvlID_Base := v_BaseLvlID || lPad(TO_Char(v_Index),6,''0'');' || chr(10);
  v_SQL := v_SQL || '      IF Nvl(C1.LevelID,''$'') = ''$'' THEN' || chr(10);
  v_SQL := v_SQL || '        UPDATE '||v_RelaTableName||' SET EndFlag = ''1'',LevelID = v_SubLvlID_Base WHERE sourceid = v_sourceid  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '      END IF;' || chr(10);
  v_SQL := v_SQL || '      IF Nvl(C1.LevelID,''$'') <> ''$'' AND Nvl(C1.LevelID,''$'') <> v_SubLvlID_Base THEN' || chr(10);
  v_SQL := v_SQL || '        UPDATE '||v_RelaTableName||' SET LevelID = v_SubLvlID_Base || SubStr(LevelID,Length(v_SubLvlID_Base) + 1) WHERE ((sourceid = C1.sourceid) OR (LevelID <> ''A'' || SubStr(C1.LevelID,2)  AND LevelID LIKE ''A'' || SubStr(C1.LevelID,2) || ''%''))  and syscode = ''' ||v_syscode ||''' and busitype= '''||v_busitype||''';' || chr(10);
  v_SQL := v_SQL || '      END IF;' || chr(10);
  v_SQL := v_SQL || '    END LOOP;' || chr(10);
  v_SQL := v_SQL || 'END;' || chr(10);
 -- INSERT INTO a(a) values(v_SQL);
--  commit;
  EXECUTE IMMEDIATE v_SQL;
--  dbms_output.put_line(v_SQL);

END;

/

