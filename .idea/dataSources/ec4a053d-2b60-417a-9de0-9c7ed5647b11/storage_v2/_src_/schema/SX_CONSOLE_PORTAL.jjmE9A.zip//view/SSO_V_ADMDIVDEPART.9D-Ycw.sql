create view SSO_V_ADMDIVDEPART as
select guid,
       superguid,
       itemcode,
       itemname,
       '['||itemcode||']'||itemname as showname,
       LEVELS,
       ORDERNUM,
       '0' as endflag,
       endflag as isleaf,
       guid admdiv,
       YEAR,
       '1' as isadmdiv,
       STATUS,
       --是否公共处室
       '0' is_pubDept,
       null as start_date,
       null as  end_date
 from sso_v_pubadmdiv
--取处室树，将处室构造到区划的下级上
union all
select guid,
       case when  superguid='#' then admdiv  else  superguid end as superguid  ,
       itemcode,
       itemname,
        '['||itemcode||']'||itemname as showname,
       levels,
       ordernum,
       endflag,
       endflag as isleaf,
       admdiv,
       year,
       '0' as isadmdiv,
       STATUS,
       --是否公共处室
       '0' as  is_pubDept,
       start_date,
       end_date
  from sso_v_pubdepartment
/

