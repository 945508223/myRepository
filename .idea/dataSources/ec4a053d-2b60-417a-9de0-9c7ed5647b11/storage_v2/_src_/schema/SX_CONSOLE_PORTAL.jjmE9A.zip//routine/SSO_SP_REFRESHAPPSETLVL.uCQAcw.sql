create PROCEDURE SSO_SP_refreshAppSetlvl(v_basetypeidID  varchar2,
                                                       v_superguid varchar2) AS
  v_sql           varchar2(4000);
  v_ordernum      varchar2(60);
  v_superOrdernum varchar2(60);
  v_guid          varchar2(32);
  v_i             number;
  v_count         number;
  type cur IS ref CURSOR;
  v_query cur;
BEGIN
  IF v_superguid IS NULL THEN
    RETURN;
  END IF;
  IF v_superguid = '#' THEN
    v_superOrdernum := '';
  ELSE
    SELECT ordernum
      INTO v_superOrdernum
      FROM dm_base_appsetdetail
     WHERE guid = v_superguid
       AND basetypeid = v_basetypeidID;
  END IF;
  v_i := 0;
  OPEN v_query FOR
    SELECT guid
      FROM dm_base_appsetdetail
     WHERE superguid = v_superguid
       AND basetypeid = v_basetypeidID
     ORDER BY orderno;
  LOOP
    FETCH v_query
      INTO v_guid;
    EXIT WHEN v_query % notfound;
    v_i        := v_i + 1;
    v_ordernum := (v_superOrdernum || lpad(v_i, 4, '0'));
    v_count    := 0;
    SELECT count(1)
      INTO v_count
      FROM dm_base_appsetdetail
     WHERE superguid = v_guid
       AND basetypeid = v_basetypeidID;
    IF v_count > 0 THEN
      UPDATE dm_base_appsetdetail
         SET ordernum = v_ordernum, endflag = '0'
       WHERE guid = v_guid
         AND basetypeid = v_basetypeidID;
      SSO_SP_refreshAppSetlvl(v_basetypeidID, v_guid);
    ELSE
      UPDATE dm_base_appsetdetail
         SET ordernum = v_ordernum, endflag = '1'
       WHERE guid = v_guid
         AND basetypeid = v_basetypeidID;
    END IF;
  END LOOP;
  CLOSE v_query;
END;
/

