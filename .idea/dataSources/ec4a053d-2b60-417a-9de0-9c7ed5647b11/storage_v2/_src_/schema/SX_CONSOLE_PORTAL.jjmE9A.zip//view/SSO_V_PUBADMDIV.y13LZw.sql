create view SSO_V_PUBADMDIV as
select ENDFLAG,
       ITEMCODE,
       ITEMNAME,
       ITEMCODE || '-' || ITEMNAME AS SHOWNAME,
       SUPERGUID,
       LEVELS,
       ORDERNUM,
       GUID,
       ISDEFAULT,
       STATUS,
       YEAR,
       GUID AS ADMDIV,
       FINADMLEVELCODE as mof_div_type,
       FINADMLEVELCODE,
       1 as is_admdiv,
       1 as IS_STANDARD
  from fw_t_admindiv
union all
--select a.endflag,a.admdivcode,a.admdivname,'['||a.admdivcode||']'||a.admdivname as showname,a.superguid,case when superguid='#' then a.levels else a.levels+1 end as levels,a.ordernum,a.guid,'1' as isdefault,a.status,a.year,a.guid AS ADMDIV , a.mof_div_type as FINADMLEVELCODE,a.is_admdiv  from sso_t_pubadmdiv_1014  a;
--新区划表
select to_char(b.is_leaf) as  endflag,
       b.code as itemcode,
       b.name as itemname,
       b.code || '-' || b.name as showname,
       b.parent_id as superguid,
       b.level_no as levels,
       to_char(b.level_no) as ordernum,
       b.mof_div_id as guid,
       '1' as isdetault,
       to_char(b.is_enabled) as status,
       b.year,
       b.guid as admdiv,
       to_char(b.mof_div_type) as mof_div_type ,
       to_char(b.mof_div_type) as FINADMLEVELCODE,
       b.is_admdiv,
       b.IS_STANDARD
 -- from BAS_MOF_DIV@basmofdiv b;
 from BAS_MOF_DIV b
/

