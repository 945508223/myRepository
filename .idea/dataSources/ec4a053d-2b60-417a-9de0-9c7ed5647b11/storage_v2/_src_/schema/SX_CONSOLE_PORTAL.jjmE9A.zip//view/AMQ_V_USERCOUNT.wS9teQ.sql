create view AMQ_V_USERCOUNT as
select a.username,
       case
         when usertype = 0 then
          a.agencyname
         else
          '财政局'
       end as agencyname,
       admdivname,
       substr(a.optime, 1, 10) as optime,
       case
         when usertype = 0 then
          '部门用户'
         else
          '财政用户'
       end usertype,
       (select remark from sso_v_causer b  where  trim(b.admdivname)= trim(a.admdivname) and  trim(b.agencyname)= trim(a.agencyname) and  trim(b.name)=trim(a.username) and rownum=1 ) as zw,
       count(a.username) as usercount
  from AMQ_OPERATIONLOG a
 where appid = 'BMP_PORTAL'
   and usertype <> '-1'
 group by a.username,
          a.agencyname,
          a.admdivname,
          substr(a.optime, 1, 10),
          usertype
/

