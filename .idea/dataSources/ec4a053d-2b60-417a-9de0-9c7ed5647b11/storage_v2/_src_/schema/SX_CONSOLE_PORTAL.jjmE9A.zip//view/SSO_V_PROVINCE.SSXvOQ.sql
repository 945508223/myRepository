create view SSO_V_PROVINCE as
select guid,itemcode,case when itemcode='87' then '财政部' else itemname end    as itemname ,year from   sso_v_pubadmdiv_all
where itemcode = '87'
union all
select guid,itemcode,itemname,year from   FW_T_ADMINDIV
/

