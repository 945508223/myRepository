create view RURAL_V_PROJRATE as
(
select a.year,
      case when groupid='1' then '73F62BFDF0EF4733883DEC4E98F722FB' else  a.admdiv end as admdiv,
      case when groupid='1' then '62' else  a.admdiv_code end as admdiv_code,
      --a.groupid,
      case when groupid='1' then  '甘肃省' else  a.admdiv_name end as admdiv_name,
      case when groupid='1' then '#' else a.SUPERGUID end as superguid,
      case when groupid='1' then '0' else a.ENDFLAG end as endflag,
       --纳入部门个数
       a.agencynum,
       --项目录入个数
       a.projnum,
       --已匹配资金项目数
       a.projpipeinum,
       --县级主管部门终审
       a.xjbm_projnum,
       --县级财政匹配资金及复核
       a.xjcz_projnum,
       --市级财政资金匹配复核
       a.sjcz_projnum,
       --省级主管部门复核
       a.gjbm_projnum,
       --省级乡村振兴部门复核
       a.gjxczx_projnum,
       --省级财政资金匹配复核
       a.gjcz_projnum
 from rural_v_projlevelnum a where (a.groupid ='0' and admdiv_code <>'62')  or (groupid='1')
union all
select b.year,b.admdiv,b.admdiv_code,b.admdiv_name,b.SUPERGUID,b.endflag,
         --纳入部门个数
       b.agencynum,
       --项目录入个数
       b.projnum,
       --已匹配资金项目数
       b.projpipeinum,
       --县级主管部门终审
       b.xjbm_projnum,
       --县级财政匹配资金及复核
       b.xjcz_projnum,
       --市级财政资金匹配复核
       b.sjcz_projnum,
       --省级主管部门复核
       b.gjbm_projnum,
       --省级乡村振兴部门复核
       b.gjxczx_projnum,
       --省级财政资金匹配复核
       b.gjcz_projnum
 from rural_v_projadmdivnum b )
/

