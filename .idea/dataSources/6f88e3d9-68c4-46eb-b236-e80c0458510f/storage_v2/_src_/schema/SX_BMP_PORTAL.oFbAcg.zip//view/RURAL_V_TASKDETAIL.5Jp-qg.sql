create view RURAL_V_TASKDETAIL as
select n.TASKNO,
       n.TASKMONTH,
       n.YEAR,
       n.TASKTYPE,  --任务分类
       n.APPID,  --任务分类所属系统
       n.TASKTYPECODE, --任务分类编码
       n.TASKCLASS, ----任务分类填报类型
       n.ADMDIV,
       n.ADMDIVCODE,
       n.ADMDIVNAME,
       n.STARTDATE,
       n.ENDDATE,
       n.SUPERTASKID,
       n.TASKID,
       n.TASKNAME,
       n.TASKSHOWNAME,
       n.TASKADMDIV,
       n.TASKADMDIVCODE,
       n.TASKADMDIVNAME ,
       '['|| n.TASKADMDIVCODE||']'||n.TASKADMDIVNAME as TASKADMDIVSHOWNAME ,
       t.superguid      as superadmdiv,
       t.endflag        as endflag,
       t.FINADMLEVELCODE as budgetlevel,
       n.TASKSTATUS, --任务状态
       （select itemname  from dm_base_codes where basetype='TASKSTATUS'  and ITEMCODE =n.TASKSTATUS) as TASKSTATUSNAME,
       n.TASKUPDATE, --上报时间
       n.TASKDOWNDATE,
       n.CHECKSTATUS,
       n.SUBUSER,      --填报人
       n.SUBDEPTMANAGER,    --科室负责人
       n.SUBMANAGER,   --单位负责人
       n.SUBADMDIVNAME,  --填报单位
       n.SUBDEPARTMENT,   --填报科室
       n.SUBUSERTEL,  --填报人电话
       n.SUBDEPTMANAGERTEL, --科室负责人电话
       n.SUBMANAGERTEL  --单位负责人电话
  from (SELECT B.TASKNO,
               A.TASKMONTH,
               A.YEAR,
               A.TASKTYPE,
               A.ADMDIV,
               A.MOF_DIV_CODE AS ADMDIVCODE,
               A.MOF_DIV_NAME AS ADMDIVNAME,
               A.STARTDATE,
               A.ENDDATE,
       /*        (select appid from RURAL_TASK_TYPE  where  guid=a.TASKTYPE  ) as APPID, --任务分类所在appid
               (select tasktypecode from RURAL_TASK_TYPE  where  guid=a.TASKTYPE ) as TASKTYPECODE, --任务分类编码*/
               c.appid, --任务分类所在appid
               c.tasktypecode, --任务分类编码
               c.tasktype as taskclass, --任务分类填报类型
               B.SUPERTASKID,
               B.GUID AS TASKID,
               A.TASKNAME,
               A.TASKNAME || '[' || nvl((select itemname
                                          from dm_base_codes
                                         where basetype = 'TASKSTATUS'
                                           and itemcode = B.TASKSTATUS),
                                        '未下达') || ']' AS TASKSHOWNAME,
               B.TASKADMDIV,
               B.TASKADMDIVCODE,
               B.TASKADMDIVNAME,
               B.TASKSTATUS,
               B.TASKUPDATE,
               B.TASKDOWNDATE,
               B.CHECKSTATUS,
               B.SUBUSER,      --填报人
               B.SUBDEPTMANAGER,    --科室负责人
               B.SUBMANAGER,   --单位负责人
               B.SUBADMDIVNAME,  --填报单位
               B.SUBDEPARTMENT,   --填报科室
               B.SUBUSERTEL,  --填报人电话
               B.SUBDEPTMANAGERTEL, --科室负责人电话
               B.SUBMANAGERTEL  --单位负责人电话
          FROM RURAL_TASK_INFO A
         RIGHT JOIN RURAL_TASK_DETAIL B
            ON A.GUID = B.SUPERTASKID
         left join  RURAL_TASK_TYPE c
           on  a.tasktype = c.guid ) n
  left join fw_t_admindiv t
    on n.taskadmdiv = t.GUID
/

