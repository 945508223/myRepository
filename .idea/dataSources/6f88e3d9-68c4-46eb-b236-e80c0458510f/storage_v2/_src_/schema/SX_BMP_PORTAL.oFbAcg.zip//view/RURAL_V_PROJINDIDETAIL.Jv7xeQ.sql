create view RURAL_V_PROJINDIDETAIL as
with proj_detail as (
   select m.guid as proj_id,
          m.admdiv,
          m.mof_div_code,
          (select itemname from fw_t_admindiv where guid = m.admdiv) as admdiv_name,
          (select superguid from fw_t_admindiv where guid = m.admdiv) as upadmdiv,
          substr(m.mof_div_code, 1, 4) as upadmdiv_code,
          (select itemname
             from fw_t_admindiv
            where itemcode = substr(m.mof_div_code, 1, 4)) as upadmdiv_name,
          (select FINADMLEVELCODE from fw_t_admindiv where guid = m.admdiv) as admdivlevel,
          m.year,
          m.pro_top,
          (select itemcode from ELE_INDUSCLASS where guid = m.pro_top) as pro_topcode,
          (select itemname from ELE_INDUSCLASS where guid = m.pro_top) as pro_topname,
          m.pro_second,
          (select itemcode from ELE_INDUSCLASS where guid = m.pro_second) as pro_secondcode,
          (select itemname from ELE_INDUSCLASS where guid = m.pro_second) as pro_secondname,
          m.PROCATID,
          (select itemcode from ELE_PROJTYPE where guid = m.PROCATID) as PROCATCODE,
          (select itemname from ELE_PROJTYPE where guid = m.PROCATID) as PROCATNAME,
          m.SPFID,
          (select itemcode from ELE_PROJTOP where guid = m.SPFID) as SPFCODE,
          (select itemname from ELE_PROJTOP where guid = m.SPFID) as SPFNAME,
          m.PROIMPLE,
          m.RESPONUSERNAME,
          m.pro_start_year,
          m.pro_end_year,
          m.proname,
          m.projmount,
          nvl(N.BENEFITVILLAGE, 0) as BENEFITVILLAGE,
          nvl(N.BENEFITHOUSE, 0) as BENEFITHOUSE,
          nvl(N.BENEFITPER, 0) as BENEFITPER,
          n.CONTENTSCALE
     from RURAL_PROJECT_INFO m
     left join RURAL_PROJECT_CONTENT N
       on M.GUID = N.PROJID
      AND M.YEAR = N.YEAR
      AND M.ADMDIV = N.ADMDIV
   ),
  proj_indi  as(
   select a.proj_id,
            a.year,
            a.indi_id,
            a.amount as indi_use_amount,
            b.PROTYPE_ID,
            (select itemname
               from ELE_FUNDCLASS
              where guid = b.protype_id) as protypename,
            b.budget_level_code,
            case b.budget_level_code
              when '1' then
               '中央'
              when '2' then
               '省'
              when '3' then
               '市'
              else
               '县'
            end as budget_level_name,
            b.exp_func_id,
            (select itemname
               from ele_expfunc
              where guid = b.exp_func_id) as exp_func_name
             from RURAL_PROJECT_CAPITAL a
             left join RURAL_INDI_INFO b
               on a.indi_id = b.guid
              and a.year = b.year
)
select a."PROJ_ID",a."ADMDIV",a."MOF_DIV_CODE",a."ADMDIV_NAME",a."UPADMDIV",a."UPADMDIV_CODE",a."UPADMDIV_NAME",a."ADMDIVLEVEL",a."YEAR",a."PRO_TOP",a."PRO_TOPCODE",a."PRO_TOPNAME",a."PRO_SECOND",a."PRO_SECONDCODE",a."PRO_SECONDNAME",a."PROCATID",a."PROCATCODE",a."PROCATNAME",a."SPFID",a."SPFCODE",a."SPFNAME",a."PROIMPLE",a."RESPONUSERNAME",a."PRO_START_YEAR",a."PRO_END_YEAR",a.proname,a."PROJMOUNT",a."BENEFITVILLAGE",a."BENEFITHOUSE",a."BENEFITPER",a."CONTENTSCALE",b.indi_use_amount,b.PROTYPE_ID,b.protypename,b.budget_level_code,b.budget_level_name,b.exp_func_id,b.exp_func_name from proj_detail a
 left join  proj_indi b
 on a.year = b.year
 and a.proj_id= b.proj_id
/

