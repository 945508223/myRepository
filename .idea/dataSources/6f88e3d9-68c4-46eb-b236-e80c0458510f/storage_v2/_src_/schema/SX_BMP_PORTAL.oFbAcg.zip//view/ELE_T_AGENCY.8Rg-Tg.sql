create view ELE_T_AGENCY as
select  a.guid,
        a.itemcode,
        a.itemname,
      '['||itemcode||']'||itemname AS itemshowname,
       a.superguid,
       a.year,
       a.levels,
       a.ORDERNUM,
       a.admdiv,
       '0' as endflag,
       '0' as isadmdiv -- 是否行政区划，0 -否 1-是
  from sso_v_pubagency@portal a
  union all
  select  a.guid,
        a.itemcode,
        a.itemname,
      '['||itemcode||']'||itemname AS itemshowname,
       a.superguid,
       a.year,
       a.levels,
       a.ORDERNUM,
       a.admdiv,
       a.endflag,
       '1' as isadmdiv -- 是否行政区划，0 -否 1-是
  from sso_v_pubadmdiv@portal a
/

