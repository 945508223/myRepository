create view ELE_V_PROJTYPETOP as
select guid,itemcode,itemname,  levels, superguid ,guid as projtype,'1' as istype,year,'0' as endflag from ele_projtype
union all
select guid,itemcode,itemname, levels+1 as levels,case when superguid='#' then projtype else superguid end as superguid,projtype,'0' as istype,year,endflag from ele_projtop
/

