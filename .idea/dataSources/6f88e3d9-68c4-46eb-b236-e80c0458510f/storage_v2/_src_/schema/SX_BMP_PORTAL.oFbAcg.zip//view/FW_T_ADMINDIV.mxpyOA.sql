create view FW_T_ADMINDIV as
select "ENDFLAG",
       "ITEMCODE",
        "ITEMNAME",
        '['||itemcode||']'||"ITEMNAME" as showname,
       "SUPERGUID",
       "LEVELS",
       "ORDERNUM",
       "GUID",
       "ISDEFAULT",
       "STATUS",
       "YEAR",
       is_admdiv,
       CASE  FINADMLEVELCODE WHEN '2' THEN '2' WHEN '3' THEN '3' WHEN '4' THEN '3' ELSE '4' END AS "FINADMLEVELCODE"
  from sso_v_pubadmdiv@portal
  --where (ENDFLAG='0' OR  (is_admdiv='1' and  FINADMLEVELCODE in ('2','4') ) ) OR is_admdiv='3'
/

