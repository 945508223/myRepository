create view RURAL_V_INDITALAMT as
select  nn.year,
        mm.guid as admdiv,
        nn.dis_agencycode as admdiv_code,
        tt.itemcode  as  projtypecode,
        tt.itemname  as  projtypename,
     /*  (select itemcode
          from ELE_FUNDCLASS
         where guid = nn.protype_id
           and rownum = 1) as projtypecode,*/
/*       (select itemname
          from ELE_FUNDCLASS
         where guid = nn.protype_id
           and rownum = 1) as projtypename,
*/       nn.BUDGET_LEVEL_CODE,
         case  nn.BUDGET_LEVEL_CODE when  '1' then '中央级' when '2' then '省级' when '3' then '市（州）级' else  '县（市、区）级'  end as budget_level_name,
      /* (select itemname
          from DM_BASE_CODES t
         where basetype = 'BUDGET_LEVEL'
           and itemcode = nn. BUDGET_LEVEL_CODE) as budget_level_name,*/
       nn.amount
  from (
        --各级财政给县级分配金额
        select a.year,
                a.dis_agencycode,
                a.protype_id,
                a.BUDGET_LEVEL_CODE,
                sum(a.dis_amount) as amount
          from RURAL_V_INDIDETAIL a
         group by a.year, a.dis_agencycode, a.protype_id, a.BUDGET_LEVEL_CODE
        union all
        --市级
          --市级自己安排的指标
        select a.year,
               substr(a.mof_div_code, 1, 4) as dis_agencycode,
               a.protype_id,
               a.BUDGET_LEVEL_CODE,
               sum(a.amount) as amount
          from RURAL_INDI_INFO a
         where a.BUDGET_LEVEL_CODE = '3'
         group by a.year,
                  substr(a.mof_div_code, 1, 4),
                  a.protype_id,
                  a.BUDGET_LEVEL_CODE
        union all
        --省级下达给市级指标的合计
        select a.year,
               substr(a.dis_agencycode, 1, 4) as dis_agencycode,
               a.protype_id,
               a.BUDGET_LEVEL_CODE,
               sum(a.dis_amount) as amount
          from RURAL_V_INDIDETAIL a
         where a.BUDGET_LEVEL_CODE <> '3'
         group by a.year,
                  substr(a.dis_agencycode, 1, 4),
                  a.protype_id,
                  a.BUDGET_LEVEL_CODE
        --省级
        union all
         --省级安排的指标
        select a.year,
               substr(a.mof_div_code, 1, 2) as dis_agencycode,
               a.protype_id,
               a.BUDGET_LEVEL_CODE,
               sum(a.amount) as amount
          from RURAL_INDI_INFO a
         group by a.year,
                  substr(a.mof_div_code, 1, 2),
                  a.protype_id,
                  a.BUDGET_LEVEL_CODE) nn
      LEFT JOIN  fw_t_admindiv MM
      ON NN.dis_agencycode = MM.itemcode
      left join  ELE_FUNDCLASS tt
      on nn.protype_id = tt.guid
/

