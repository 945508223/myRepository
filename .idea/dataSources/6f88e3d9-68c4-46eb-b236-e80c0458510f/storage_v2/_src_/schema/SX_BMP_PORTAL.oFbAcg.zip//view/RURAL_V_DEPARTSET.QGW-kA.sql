create view RURAL_V_DEPARTSET as
select a."GUID" as agencyid,  --单位id
       a."ITEMCODE",
       a."ITEMNAME",
       a."SUPERGUID",
       a."ENDFLAG",
       a."YEAR",
       a."ISLEAF",
       a."ISADMDIV",
       a."ADMDIV",
       a."STATUS",
       a."LEVELS",
       a."ORDERNUM",
       a."SHOWNAME",
       a.departtype,   --部门口径
       a.guid,         --部门口径id
       a.BUDGET_LEVEL,
       case when a.isleaf='1' and a.budget_level in ('2','3') then  (select superguid from fw_t_admindiv where guid=a.admdiv) else a.admdiv end as upadmdiv
  from SSO_V_ADMDIVAGENCY a    --区划单位表
/

