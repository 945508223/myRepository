create view ELE_V_PROJTYPECLASS as
select guid,itemcode,itemname,  levels, superguid ,guid as indusclass,'1' as istype,year,'0' as endflag  from ELE_INDUSCLASS
union all
select guid,itemcode,itemname,  levels+2,case when superguid='#' then indusclass else superguid end as superguid , indusclass,'0' as istype,year, endflag from ele_projtype
/

