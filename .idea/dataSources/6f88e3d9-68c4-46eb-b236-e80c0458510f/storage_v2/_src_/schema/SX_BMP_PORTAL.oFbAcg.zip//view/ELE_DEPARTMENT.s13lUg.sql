create view ELE_DEPARTMENT as
select "ENDFLAG","GUID","ITEMCODE","ITEMNAME","LEVELS","ORDERNUM","SUPERGUID","YEAR" from sso_t_departtype@portal
/

