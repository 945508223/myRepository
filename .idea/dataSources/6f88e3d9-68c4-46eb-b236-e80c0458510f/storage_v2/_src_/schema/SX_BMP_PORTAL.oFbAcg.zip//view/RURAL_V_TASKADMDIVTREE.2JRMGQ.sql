create view RURAL_V_TASKADMDIVTREE as
select n.SUPERTASKID||TASKADMDIV  as guid,
       n.TASKNO,
       n.TASKMONTH,
       n.TASKTYPE,
       n.ADMDIV,
       n.ADMDIVCODE,
       n.ADMDIVNAME,
       N.STARTDATE,
       N.ENDDATE,
       n.SUPERTASKID,
       n.TASKID,
       n.TASKNAME,
       n.TASKADMDIV,
       n.TASKADMDIVCODE,
       n.TASKADMDIVNAME,
       n.TASKADMDIVSHOWNAME  as taskshowname,
       n.SUPERADMDIV ,
       n.endflag,
       '0' as ismast,
       n.budgetlevel,
       n.TASKSTATUS,
       n.TASKUPDATE,
       N.TASKDOWNDATE
  from RURAL_V_TASKDETAIL n
  where n.taskstatus <> '0'
/

