create materialized view TASK_V_SB2022_T56
    refresh force on demand
as
select A.GUID,A.TASKID as TASKID,B.SUPERTASKID,C.ITEMCODE,C.ITEMNAME,
     --预算安排数
     A.AMOUNT,
     --上期预算数
     A.PAMOUNT,
     --测算人数
     A.PERSONCNT,
     --按保障标准计算的需求数
     A.NEEDAMOUNT,
     --保障标准
     A.STANDARDAMOUNT,
    B.TASKADMDIVCODE, B.TASKADMDIVNAME,B.TASKADMDIV,B.ENDFLAG,to_number(substr(B.TASKMONTH,6)) as MONTH,2022 as YEAR from SB2022_T56 A
    RIGHT join RURAL_V_TASKDETAIL B on A.TASKID=B.TASKID
    left join SB_BASE_SBKM C ON A.ITEMCODE=C.ITEMCODE
/

