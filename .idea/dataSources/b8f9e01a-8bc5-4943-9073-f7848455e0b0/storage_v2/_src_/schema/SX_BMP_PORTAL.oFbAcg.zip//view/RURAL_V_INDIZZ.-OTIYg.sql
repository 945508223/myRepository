create view RURAL_V_INDIZZ as
(
select "YEAR","ADMDIV","ADMDIV_CODE","AMOUNT1_ZY","AMOUNT1_GJ","AMOUNT1_SXJ","AMOUNT2_ZY","AMOUNT2_GJ","AMOUNT2_SXJ","AMOUNT3_ZY","AMOUNT3_GJ","AMOUNT3_SXJ","AMOUNT4_ZY","AMOUNT4_GJ","AMOUNT4_SXJ","AMOUNT5_ZY","AMOUNT5_GJ","AMOUNT5_SXJ","AMOUNT6_ZY","AMOUNT6_GJ","AMOUNT6_SXJ","AMOUNT7_ZY","AMOUNT7_GJ","AMOUNT7_SXJ","AMOUNT8_ZY","AMOUNT8_GJ","AMOUNT8_SXJ","AMOUNT9_ZY","AMOUNT9_GJ","AMOUNT9_SXJ","AMOUNT10_ZY","AMOUNT10_GJ","AMOUNT10_SXJ" from (
  select  year,admdiv,admdiv_code,projtypecode,zy_amount,gj_amount,sj_amount,xj_amount from rural_v_inditalamtzz
)
pivot (
   sum(zy_amount) as zy, sum(gj_amount) as gj,sum(sj_amount+xj_amount) as sxj
   for projtypecode in ('001' as amount1,'002' as amount2,'003' as amount3,'004' as amount4,'005' as amount5,'006' as amount6,'007' as amount7,'008' as amount8,'009' as amount9,'010' as amount10)
      ) )
/

