create view SSO_V_DISTRICT as
SELECT  GUID,
        GUID AS DISTRICTID ,
        ITEMCODE,
        ITEMNAME,
        '['||ITEMCODE||']'||ITEMNAME AS SHOWNAME,
        SUPERGUID,
        ENDFLAG,
        LEVELS,
        YEAR
FROM  SSO_V_PUBADMDIV
/

