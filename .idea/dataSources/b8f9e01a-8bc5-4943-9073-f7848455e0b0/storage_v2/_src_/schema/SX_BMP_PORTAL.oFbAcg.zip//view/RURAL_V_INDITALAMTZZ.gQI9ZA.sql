create view RURAL_V_INDITALAMTZZ as
select  nn.year,
        nn.admdiv,
        nn.admdiv_code,
        mm.itemname as admdiv_name,
    --   (select itemname  from fw_t_admindiv where guid=admdiv and rownum=1 ) as admdiv_name,
        nn.projtypecode,
        nn.projtypename,
       --指标下达的金额
       nvl(round(sum(nn.zy_amount) / 10000, 2),0) as zy_amount,
       nvl(round(sum(nn.gj_amount) / 10000, 2),0) as gj_amount,
       nvl(round(sum(nn.sj_amount) / 10000, 2),0) as sj_amount,
       nvl(round(sum(nn.xj_amount) / 10000, 2),0) as xj_amount,
       --指标挂接项目的金额
       nvl(round(sum(nn.zy_pro_amount) / 10000, 2),0) as zy_pro_amount,
       nvl(round(sum(nn.gj_pro_amount) / 10000, 2),0) as gj_pro_amount,
       nvl(round(sum(nn.sj_pro_amount) / 10000, 2),0) as sj_pro_amount,
       nvl(round(sum(nn.xj_pro_amount) / 10000, 2),0) as xj_pro_amount,
       --指标剩余的金额
       nvl(round( ( sum(nn.zy_amount) - sum(nn.zy_pro_amount) )  / 10000, 2),0) as zy_res_amount,
       nvl(round( ( sum(nn.gj_amount) - sum(nn.gj_pro_amount) ) / 10000, 2),0) as gj_res_amount,
       nvl(round( ( sum(nn.sj_amount) - sum(nn.sj_pro_amount) ) / 10000, 2),0) as sj_res_amount,
       nvl(round( ( sum(nn.xj_amount) - sum(nn.xj_pro_amount) )/ 10000, 2),0)  as xj_res_amount

  from (

        --指标下达金额统计
        select  year,
                admdiv,
                admdiv_code,
                projtypecode,
                projtypename,
                BUDGET_LEVEL_CODE,
                decode(BUDGET_LEVEL_CODE,'1',nvl(amount,0)) as zy_amount,  --中央
                decode(BUDGET_LEVEL_CODE,'2',nvl(amount,0)) as gj_amount,  --省级
                decode(BUDGET_LEVEL_CODE,'3',nvl(amount,0)) as sj_amount,  --市级
                decode(BUDGET_LEVEL_CODE,'4',nvl(amount,0)) as xj_amount,  --县级
                0 as zy_pro_amount,
                0 as gj_pro_amount,
                0 as sj_pro_amount,
                0 as xj_pro_amount
          from rural_v_inditalamt
       union all
        --指标挂接项目金额统计
        --中央
        select year,
               admdiv,
               mof_div_code as admdiv_code,
               projtypecode,
               projtypename,
               BUDGET_LEVEL_CODE,
               0 as zy_amount,
               0 as gj_amount,
               0 as sj_amount,
               0 as xj_amount,
               decode(BUDGET_LEVEL_CODE,'1',nvl(amount,0)) as zy_pro_amount,  --中央
               decode(BUDGET_LEVEL_CODE,'2',nvl(amount,0)) as gj_pro_amount,  --省级
               decode(BUDGET_LEVEL_CODE,'3',nvl(amount,0)) as sj_pro_amount,  --市级
               decode(BUDGET_LEVEL_CODE,'4',nvl(amount,0)) as xj_pro_amount   --县级
          from RURAL_V_INDITOPROJECT n
              ) nn
              left join fw_t_admindiv mm
              on nn.admdiv = mm.guid
 group by nn.year, nn.admdiv, nn.admdiv_code,mm.itemname, nn.projtypecode, nn.projtypename
/

