create view BASE_V_AMOUNT1 as
with MS AS (
--县级
 select  substr（c.province,1,6) as province, '3' as fl,  d.itemcode kmbm,c.sbxmfl_name pro_name,sum(c.amt01) as amt01 from BAS_T_BGTSB c
 left join  SB2022_H_SBTAGMAP d
 on c.sbxmfl_code = d.tagcode
 where c.sbxmfl_code<>'401' AND  (  SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,2) <> '00'  and  SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,1) <> '9'  )
 group by  substr（c.province,1,6),d.itemcode,c.sbxmfl_name
UNION ALL
 select substr（province,1,6) as province,'1' as fl, kmbm as kmbm,a.pro_name,sum(a.bmysamt) as amt01
 from TEMP_T_SBYS  a
 where   SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,2) <> '00'  and  SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,1) <> '9'
 group by  substr（province,1,6),kmbm,pro_name
--市本级
union all
  select  substr（c.province,1,4)||'00' as province, '3' as fl,d.itemcode kmbm,c.sbxmfl_name pro_name,sum(c.amt01) as amt01 from BAS_T_BGTSB c
 left join  SB2022_H_SBTAGMAP d
 on c.sbxmfl_code = d.tagcode
 where c.sbxmfl_code<>'401' AND  (  SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,2) = '00'  or SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,1) = '9'  )
 group by   substr(c.province,1,4),d.itemcode,c.sbxmfl_name
 UNION ALL
 select substr(province,1,4)||'00' as province, '1' as fl,kmbm as kmbm,a.pro_name,sum(a.bmysamt) as amt01
 from TEMP_T_SBYS  a
 where (  SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,2)= '00'  or SUBSTR(PROVINCE,LENGTH(PROVINCE)-1,1) = '9'  )
 group by  substr(province,1,4),kmbm,pro_name
--市级汇总
union all
  select  substr（c.province,1,4) as province, '3' as fl,d.itemcode kmbm,c.sbxmfl_name pro_name,sum(c.amt01) as amt01 from BAS_T_BGTSB c
 left join  SB2022_H_SBTAGMAP d
 on c.sbxmfl_code = d.tagcode
 where c.sbxmfl_code<>'401'
 group by   substr(c.province,1,4),d.itemcode,c.sbxmfl_name
 UNION ALL
 select substr(province,1,4) as  province, '1' as fl,kmbm as kmbm,a.pro_name,sum(a.bmysamt) as amt01
 from TEMP_T_SBYS  a
 group by  substr(province,1,4),kmbm,pro_name
 --省级汇总
 union all
  select  substr（c.province,1,2) as province,'3' as fl, d.itemcode kmbm,c.sbxmfl_name pro_name,sum(c.amt01) as amt01 from BAS_T_BGTSB c
 left join  SB2022_H_SBTAGMAP d
 on c.sbxmfl_code = d.tagcode
 where c.sbxmfl_code<>'401'
 group by   substr(c.province,1,2),d.itemcode,c.sbxmfl_name
 UNION ALL
 select substr(province,1,2) as  province,'1' as fl, kmbm as kmbm,a.pro_name,sum(a.bmysamt) as amt01
 from TEMP_T_SBYS  a
 group by  substr(province,1,2),kmbm,pro_name

),
ADMDIV AS (
 SELECT * FROM fw_t_admindiv
)

SELECT  M.GUID,M.ITEMCODE,M.ITEMNAME,M.ENDFLAG,n.fl,N.kmbm,N.pro_name,N.amt01
FROM       ADMDIV M
LEFT JOIN  MS     N
ON  M.ITEMCODE =N.PROVINCE
where length(m.itemcode)<=6
and SUBSTR(m.itemcode,LENGTH(m.itemcode)-1,1) <> '9'
/

