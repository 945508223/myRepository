create materialized view TASK_V_R1_REPORTYSJS
    refresh force on demand
as
with admdiv as (
select  b.fundlevel,b.fundcn, a.TASKADMDIV,a.TASKADMDIVCODE,a.TASKADMDIVNAME,a.TASKID,a.SUPERTASKID,a.endflag,a.TASKMONTH
from RURAL_V_TASKDETAIL   a   ,
(select  '1' as fundlevel,'中央' as fundcn  from dual
union
select  '2' as fundlevel,'省级' as fundcn from dual
union
select  '3' as fundlevel,'省本级' as fundcn from dual
union
select  '4' as fundlevel,'市（州）级' as fundcn from dual
union
select  '5' as fundlevel,'市（州）本级' as fundcn from dual
union
select  '6' as fundlevel,'县（市、区）级' as fundcn from dual   )b

),
--2020年预算决算（1-中央、2-省、 3-省本级 4-市 5-市本级、6-县）
zj1 as (
  select  supertaskid,taskid,taskadmdivcode,taskadmdivname,fundlevel,
   nvl(sum(a0101_zc),0) as a0101,
  nvl(sum(a0102_zc),0) as a0102,
  nvl(sum(a0103_zc),0) as a0103,
  nvl(sum(a0104_zc),0) as a0104,
  nvl(sum(a0105_zc),0) as a0105,
  nvl(sum(a0106_zc),0) as a0106,
  nvl(sum(a0107_zc),0) as a0107,
  nvl(sum(a0108_zc),0) as a0108,
  nvl(sum(a0109_zc),0) as a0109
     from
  (
   select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,t.fundlevel,t.fundname,sum(t.finalamount) as ysjs
   from TASK_V_R1_REPORTDATAS t
   where  fundname LIKE '01%'
   group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,fundlevel,t.fundname
  )
  pivot(sum(ysjs) as zc  for  fundname in( '0101' as a0101,'0102' as a0102,'0103' as a0103,'0104' as a0104,'0105' as a0105,'0106' as a0106,
      '0107' as a0107,'0108' as a0108 ,'0109' as a0109

       ) )
  group by supertaskid,taskid,taskadmdivcode,taskadmdivname,fundlevel
)

select '2021' as year, aa.supertaskid,aa.taskid,aa.taskadmdivcode,aa.taskadmdivname,aa.endflag,aa.TASKMONTH,aa.fundlevel,aa.fundcn,

--2020年支出预算
round(kk.a0101,0) as a0101,
round(kk.a0102,0) as a0102,
round(kk.a0103,0) as a0103,
round(kk.a0104,0) as a0104,
round(kk.a0105,0) as a0105,
round(kk.a0106,0) as a0106,
round(kk.a0107,0) as a0107,
round(kk.a0108,0) as a0108,
round(kk.a0109,0) as a0109

from  admdiv aa
left join zj1 kk
on    aa.supertaskid= kk.supertaskid
and   aa.taskid=kk.taskid
and   aa.taskadmdivcode=kk.taskadmdivcode
and   aa.taskadmdivname=kk.taskadmdivname
and   aa.fundlevel=kk.fundlevel
/

