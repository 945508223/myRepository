create view BASE_V_AMOUNT as
(
select  B.GUID,b.ITEMCODE,b.ITEMNAME,b.endflag,aa.kmbm,aa.amt01 from (
 select a.province,a.province_name,substr(a.kmbm,1,2) as kmbm,sum(a.bmysamt) as amt01
 from TEMP_T_SBYS  a
 group by  a.province,a.province_name,substr(a.kmbm,1,2)
 union all
 select province,province_name,'03' as kmbm,sum(amt01) as amt01 from BAS_T_BGTSB
 group by  province,province_name
 ) aa
  right join fw_t_admindiv B on B.itemcode = aa.province )
/

