create view RURAL_V_PROJLEVELNUM as
with fw_admindiv as(
select n.year,n.GUID,n.ITEMCODE ,n.ITEMNAME,n.ENDFLAG,n.SUPERGUID from fw_t_admindiv n
),

proj_level as (
select m.year,m.SUPERGUID as admdiv ,grouping_id(m.year,
                   m.superguid
                   ) groupid,
           --纳入部门个数
       nvl(sum(m.agencynum), 0) as agencynum,
       --项目录入个数
       nvl(sum(m.projnum), 0) as projnum,
       --已匹配资金项目数
       nvl(sum(m.projpipeinum), 0) as projpipeinum,
       --县级主管部门终审
       nvl(sum(m.xjbm_projnum), 0) as xjbm_projnum,
       --县级财政匹配资金及复核
       nvl(sum(m.xjcz_projnum), 0) as xjcz_projnum,
       --市级财政资金匹配复核
       nvl(sum(m.sjcz_projnum), 0) as sjcz_projnum,
       --省级主管部门复核
       nvl(sum(m.gjbm_projnum), 0) as gjbm_projnum,
       --省级乡村振兴部门复核
       nvl(sum(m.gjxczx_projnum), 0) as gjxczx_projnum,
       --省级财政资金匹配复核
       nvl(sum(m.gjcz_projnum), 0) as gjcz_projnum
  from rural_v_projadmdivnum  m
 group by rollup(m.year,m.superguid)
)

select mm.year,
       mm.admdiv,
       fw.itemcode as admdiv_code,
       fw.itemname as admdiv_name,
       fw.SUPERGUID,
       fw.endflag,
       mm.groupid,
       --纳入部门个数
       nvl(mm.agencynum, 0) as agencynum,
       --项目录入个数
       nvl(mm.projnum, 0) as projnum,
       --已匹配资金项目数
       nvl(mm.projpipeinum, 0) as projpipeinum,
       --县级主管部门终审
       nvl(mm.xjbm_projnum, 0) as xjbm_projnum,
       --县级财政匹配资金及复核
       nvl(mm.xjcz_projnum, 0) as xjcz_projnum,
       --市级财政资金匹配复核
       nvl(mm.sjcz_projnum, 0) as sjcz_projnum,
       --省级主管部门复核
       nvl(mm.gjbm_projnum, 0) as gjbm_projnum,
       --省级乡村振兴部门复核
       nvl(mm.gjxczx_projnum, 0) as gjxczx_projnum,
       --省级财政资金匹配复核
       nvl(mm.gjcz_projnum, 0) as gjcz_projnum
  from fw_admindiv fw
  right join proj_level mm
    on fw.year = mm.year
   and fw.guid = mm.admdiv
/

