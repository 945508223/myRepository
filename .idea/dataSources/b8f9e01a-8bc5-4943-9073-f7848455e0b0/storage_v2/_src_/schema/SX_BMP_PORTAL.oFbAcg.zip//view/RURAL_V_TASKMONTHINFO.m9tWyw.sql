create view RURAL_V_TASKMONTHINFO as
select taskmonth as guid,
       taskmonth as TASKNO,
       taskmonth as TASKNAME,
       '#' as superguid,
       '0' as endflag,
       taskstatus,
       YEAR,
       ADMDIV
  from RURAL_TASK_INFO
 group by taskmonth, YEAR, ADMDIV,taskstatus
UNION ALL
SELECT GUID,
       TASKMONTH || '-' || TASKNO AS TASKNO,
       TASKNAME,
       TASKMONTH AS SUPERGUID,
       '1' AS ENDFLAG,
       taskstatus,
       YEAR,
       ADMDIV
  FROM RURAL_TASK_INFO
/

