create view RURAL_V_INDIDETAIL as
with project_capital as
 (SELECT year, admdiv, indi_id, indi_detailid, sum(amount) as proj_amount
    FROM RURAL_PROJECT_CAPITAL
   group by year, admdiv, indi_id, indi_detailid),
--取指标主表与明细表中指标分配金额及指标属性
indi_detail as
 (select a.guid as indi_id, --指标主单ID
         a.year,
         a.admdiv, --制单区划
         a.mof_div_code, --制单区划code
         (select itemname from fw_t_admindiv where guid= a.admdiv and rownum='1') as mof_div_name, --制单区划名称
         a.cor_bgt_doc_no, -- 指标文号
         a.sup_bgt_doc_no, --上级指标文号
         a.bgt_doc_title, --指标标题
         a.doc_date, --发文日期
         a.bgt_dec,
         a.exp_func_id,
         a.gov_bgt_eco_id,
         a.dep_bgt_eco_id,
         a.bgt_mof_dep,
         a.fund_type_id,
         a.found_type_id, --资金分类
         a.amount, -- 指标金额
         (a.amount - a.dis_amount) as balan_amount, --总指标可用余额
         a.create_time,
         a.create_user,
         a.indi_type_id,
         a.protype_id,
         a.budget_level_code， b.guid as indi_detailid, --指标明细ID
         b.dis_agency, -- 分配单位id
         b.dis_agencycode, --分配单位编码
         (select itemname from fw_t_admindiv  where guid= b.dis_agency and rownum='1') as dis_agencyname, --分配单位名称
         b.amount as dis_amount, --分配金额
         b.isup --是否下达
    from rural_indi_info a, rural_indi_detail b
   where a.guid = b.indi_id
     and a.year = b.year)

select m."INDI_ID",m."YEAR",m."ADMDIV",m."MOF_DIV_CODE",m."COR_BGT_DOC_NO",m."SUP_BGT_DOC_NO",m."BGT_DOC_TITLE",m."DOC_DATE",m."BGT_DEC",m."EXP_FUNC_ID",m."GOV_BGT_ECO_ID",m."DEP_BGT_ECO_ID",m."BGT_MOF_DEP",m."FUND_TYPE_ID",m."FOUND_TYPE_ID",m."CREATE_TIME",m."CREATE_USER",m."INDI_TYPE_ID",m."PROTYPE_ID",m."BUDGET_LEVEL_CODE",m."INDI_DETAILID",m."DIS_AGENCY",m."DIS_AGENCYCODE",m."ISUP",
       m.mof_div_name,m.dis_agencyname,
       nvl(m.AMOUNT,0) as amount,  --指标主表上指标总金额
       nvl(m.BALAN_AMOUNT,0) as BALAN_AMOUNT, --指标主表上指标未下达金额
       nvl(m.DIS_AMOUNT,0) as DIS_AMOUNT, --指标下达金额，即指标明细金额
       nvl(n.proj_amount, 0) as USE_AMOUNT, --指标已挂接金额,即项目合计金额
       (m.dis_amount - nvl(n.proj_amount, 0)) as REST_AMOUNT -- 指标可用余额
  from indi_detail m
  left join project_capital n
    on m.indi_id = n.indi_id
   and m.indi_detailid = n.indi_detailid
/

