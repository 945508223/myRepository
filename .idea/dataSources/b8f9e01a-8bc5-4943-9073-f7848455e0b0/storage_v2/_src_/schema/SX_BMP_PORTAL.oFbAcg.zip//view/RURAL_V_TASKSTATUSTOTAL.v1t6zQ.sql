create view RURAL_V_TASKSTATUSTOTAL as
(
  select b.supertaskid,
         b.taskid,
         a.taskupnum,
         a.statusupname,
         a.upmindate,
         a.upmaxdate,
         c.taskreturnnum,
         c.statusreturnname,
         c.returnmindate,
         c.returnmaxdate,
         b.TASKADMDIV,
         b.TASKADMDIVCODE,
         b.TASKADMDIVNAME,
         b.YEAR,
         b.endflag,
         b.TASKSTATUS,
         b.superadmdiv,
         b.budgetlevel,
         b.SUBUSER,
         B.SUBUSERTEL, --填报人电话
         B.SUBDEPTMANAGERTEL, --科室负责人电话
         B.SUBMANAGERTEL --单位负责人电话
    from  rural_v_taskdetail b
    left join  (

          --上报次数及最小最大时间
          select t.supertaskid,
                  t.taskid,
                  count(1) as taskupnum,
                  '上报' as statusupname,
                  min(t.create_time) as upmindate,
                  max(t.create_time) upmaxdate
            from RURAL_TASK_HISTORY t
           where  t.taskstatus = '22'
           group by t.supertaskid, t.taskid ) a


      on  b.supertaskid = a.supertaskid
     and  b.TASKID = a.taskid
    left join (
          --退回次数及最小最大时间
          select t.supertaskid,
                 t.taskid,
                 count(1) as taskreturnnum,
                 '退回' as statusreturnname,
                 min(t.create_time) as returnmindate,
                 max(t.create_time)as  returnmaxdate
            from RURAL_TASK_HISTORY t
           where t.taskstatus like '11%'
           group by t.supertaskid, t.taskid)  c

      on  b.supertaskid = c.supertaskid
     and  b.TASKID = c.taskid

  )
/

