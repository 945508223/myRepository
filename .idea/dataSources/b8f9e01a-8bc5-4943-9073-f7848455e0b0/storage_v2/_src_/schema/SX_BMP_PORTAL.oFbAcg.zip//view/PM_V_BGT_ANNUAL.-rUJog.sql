create view PM_V_BGT_ANNUAL as
with admdiv as
 (select a.YEAR,
         a.ITEMCODE,
         a.ITEMNAME,
         a.GUID,
         a.ADMDIV,
         a.SHOWNAME,
         a.endflag,
         a.mof_div_type,
         a.superguid,
         a.FINADMLEVELCODE
    from sso_v_pubadmdiv a),
--单位表
agency as
 (select a.YEAR, a.ITEMCODE, a.ITEMNAME, a.GUID, a.ADMDIV
    from sso_v_admdivagency a),
--处室表
department as
 (select a.YEAR,
         a.ITEMCODE,
         a.ITEMNAME,
         a.GUID,
         a.ADMDIV,
         a.SUPERGUID,
         a.admdivcode
    from sso_v_pubdepartment a),
--支出功能科目
EXP_FUNC as
 (select c.FISCAL_YEAR AS YEAR,
         c.EXP_FUNC_CODE,
         c.EXP_FUNC_NAME,
         c.EXP_FUNC_ID,
         c.PARENT_ID,
         c.IS_LEAF,
         c.LEVEL_NO,
         c.FUND_TYPE_CODE,
         c.FUND_TYPE_NAME
    from BAS_EXP_FUNC c),
--经济科目
DEP_BGT_ECO as
 (select d.FISCAL_YEAR AS YEAR,
         d.DEP_BGT_ECO_CODE,
         d.DEP_BGT_ECO_NAME,
         d.DEP_BGT_ECO_ID,
         d.PARENT_ID,
         d.IS_LEAF,
         d.LEVEL_NO
    from BAS_DEP_BGT_ECO d),
--政府经济科目
GOV_BGT_ECO as
 (select e.FISCAL_YEAR AS YEAR,
         e.GOV_BGT_ECO_CODE,
         e.GOV_BGT_ECO_NAME,
         e.GOV_BGT_ECO_ID,
         e.PARENT_ID,
         e.IS_LEAF,
         e.LEVEL_NO
    from BAS_GOV_BGT_ECO e)

--项目信息表
SELECT N.MOF_DIV_CODE,
       admdiv.ITEMNAME              AS MOF_DIV_NAME,
        decode(admdiv.MOF_DIV_TYPE||admdiv.endflag,
        '20',substr(admdiv.ITEMCODE,1,2),
        '21',substr(admdiv.ITEMCODE,1,4),
        '30',substr(admdiv.ITEMCODE,1,4),
        '31',substr(admdiv.ITEMCODE,1,6),
        '40',substr(admdiv.ITEMCODE,1,4),
        '41',substr(admdiv.ITEMCODE,1,6),
        '51',substr(admdiv.ITEMCODE,1,6),
        '511',substr(admdiv.ITEMCODE,1,6),
        '521',substr(admdiv.ITEMCODE,1,6) ) as MOF_STRDIV_CODE,
       M.PRO_ID,
       M.PRO_CODE,
       M.PRO_NAME,
       M.PRO_CAT_CODE,
       M.AGENCY_CODE,
       agency.ITEMNAME              AS AGENCY_NAME,
       M.MOF_DEP_CODE,
       M.PRO_DESC,
       --政策依据
       M.PRO_BASES,
       --是否三保
       M.V_COL27,
       --三保标识
       M.V_COL28,
       N.FISCAL_YEAR,
       N.PRO_KIND_CODE,
       N.FUND_TYPE_CODE,
       N.EXP_FUNC_CODE,
       EXP_FUNC.EXP_FUNC_NAME,
       N.DEP_BGT_ECO_CODE,
       DEP_BGT_ECO.DEP_BGT_ECO_NAME,
       N.GOV_BGT_ECO_CODE,
       GOV_BGT_ECO.GOV_BGT_ECO_NAME,
       N.APPLY_UP
  FROM PM_PROJECT_INFO@IFMIS M
--部门预算申报表
 RIGHT JOIN (SELECT AA.MOF_DIV_CODE,
                    AA.AGENCY_CODE,
                    AA.FISCAL_YEAR,
                    AA.PRO_CODE,
                    AA.PRO_KIND_CODE,
                    AA.FUND_TYPE_CODE,
                    AA.EXP_FUNC_CODE,
                    AA.DEP_BGT_ECO_CODE,
                    AA.GOV_BGT_ECO_CODE,
                   nvl( SUM(AA.APPLY_UP)/10000,0)  AS APPLY_UP
               FROM BGT_PM_ANNUAL@IFMIS AA
              GROUP BY AA.MOF_DIV_CODE,
                       AA.AGENCY_CODE,
                       AA.FISCAL_YEAR,
                       AA.PRO_CODE,
                       AA.PRO_KIND_CODE,
                       AA.FUND_TYPE_CODE,
                       AA.EXP_FUNC_CODE,
                       AA.DEP_BGT_ECO_CODE,
                       AA.GOV_BGT_ECO_CODE) N
    ON N.FISCAL_YEAR = M.YEAR
   AND N.MOF_DIV_CODE = M.MOF_DIV_CODE
   AND N.PRO_CODE = M.PRO_CODE
   AND N.AGENCY_CODE = M.AGENCY_CODE
  LEFT JOIN admdiv
    ON M.YEAR = ADMDIV.YEAR
   AND M.MOF_DIV_CODE = ADMDIV.ITEMCODE
  LEFT JOIN agency
    ON M.YEAR = agency.YEAR
   AND M.AGENCY_CODE = agency.ITEMCODE
  LEFT JOIN EXP_FUNC
    ON N.FISCAL_YEAR = EXP_FUNC.YEAR
   AND N.EXP_FUNC_CODE = EXP_FUNC.EXP_FUNC_CODE
  LEFT JOIN DEP_BGT_ECO
    ON N.FISCAL_YEAR = DEP_BGT_ECO.YEAR
   AND N.DEP_BGT_ECO_CODE = DEP_BGT_ECO.DEP_BGT_ECO_CODE
  LEFT JOIN GOV_BGT_ECO
    ON N.FISCAL_YEAR = GOV_BGT_ECO.YEAR
   AND N.GOV_BGT_ECO_CODE = GOV_BGT_ECO.GOV_BGT_ECO_CODE
--WHERE  M.IS_DELETED <> '2'
--AND    N.IS_DELETED <> '2'
/

