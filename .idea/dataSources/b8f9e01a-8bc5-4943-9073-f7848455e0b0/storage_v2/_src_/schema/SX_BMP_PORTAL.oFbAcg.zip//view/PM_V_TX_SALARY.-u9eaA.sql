create view PM_V_TX_SALARY as
select  a."MOF_DIV_CODE",a."MOF_DIV_NAME",a."MOF_STRDIV_CODE",a."PRO_ID",a."PRO_CODE",a."PRO_NAME",a."PRO_CAT_CODE",a."AGENCY_CODE",a."AGENCY_NAME",a."MOF_DEP_CODE",a."PRO_DESC",a."PRO_BASES",a."V_COL27",a."V_COL28",a."FISCAL_YEAR",a."PRO_KIND_CODE",a."FUND_TYPE_CODE",a."EXP_FUNC_CODE",a."EXP_FUNC_NAME",a."DEP_BGT_ECO_CODE",a."DEP_BGT_ECO_NAME",a."GOV_BGT_ECO_CODE",a."GOV_BGT_ECO_NAME",a."APPLY_UP",
        b.ele_name as SB_XMFL

  from PM_V_BGT_ANNUAL a
  left join ELE_SBXMFL b
  on  a.V_COL28 = b.ele_code
  --and a.MOF_DIV_CODE = b.mof_div_code
  and a.FISCAL_YEAR = b.fiscal_year
----保工资、保基本民生
 where v_col27 in ('01', '03')
/

