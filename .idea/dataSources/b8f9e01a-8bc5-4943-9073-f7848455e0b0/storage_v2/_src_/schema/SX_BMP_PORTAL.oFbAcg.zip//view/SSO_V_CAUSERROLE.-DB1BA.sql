create view SSO_V_CAUSERROLE as
select  "USERGUID","CODE","NAME","ADMDIV","AGENCYID","ROLEGUID","ROLECODE","ROLENAME" from sso_v_causerrole@portal
/

