create view BAS_GOV_BGT_ECO as
SELECT ELE_ID         AS GOV_BGT_ECO_ID,
       ELE_CODE       AS GOV_BGT_ECO_CODE,
       ELE_NAME       AS GOV_BGT_ECO_NAME,
       PROVINCE       AS MOF_DIV_CODE,
       START_DATE,
       END_DATE,
       PARENT_ID,
       LEVEL_NO,
       IS_LEAF,
       IS_ENABLED,
       UPDATE_TIME,
       IS_DELETED,
       '' AS FUND_TYPE_CODE,
       '' AS FUND_TYPE_NAME,
       FISCAL_YEAR,
       IS_STANDARD,
       CREATE_TIME
FROM   ELE_VD10005
/

