create view TASK_V_REPORT as
select nn.taskadmdivname as 区划名称,
       nn.year as 年度,
       case when nn.ysjs  =0 then null else nn.ysjs   end as  支出决算数 ,
       case when nn.ncys=0 then null else   nn.ncys end   as  年初预算 ,
       case when nn.zy_ncys=0  then null else   nn.zy_ncys  end    as  中央级,
       case when nn.gj_ncys=0 then null else   nn.gj_ncys   end   as  省级,
       case when nn.sj_ncys=0 then null else    nn.sj_ncys  end   as  市级 ,
       case when nn.xj_ncys=0 then null else   nn.xj_ncys end     as  县级 ,
       case when nn.snjz=0 then null else   nn.snjz end          as  上年结转 ,
       case when nn.bdys  =0 then null else   nn.bdys end       as  变动预算 ,
       case when nn.amount_hj =0 then null else nn.amount_hj end     as  累计支出合计 ,
       case when nn.a213  =0 then null else   nn.a213 end       as  a213农林水支出合计 ,
       case when nn.a21301=0 then null else   nn.a21301 end       as  a21301 ,
       case when nn.a21302  =0 then null else  nn.a21302 end      as  a21302 ,
       case when nn.a21303 =0 then null else    nn.a21303 end    as  a21303 ,
       case when nn.a21305 =0 then null else   nn.a21305 end     as  a21305 ,
       case when nn.a21307  =0 then null else  nn.a21307 end     as  a21307 ,
       case when nn.a21308  =0 then null else  nn.a21308 end     as  a21308 ,
       case when nn.a21309  =0 then null else  nn.a21309 end     as  a21309 ,
       case when nn.a21399 =0 then null else   nn.a21399 end     as  a21399 ,
       case when nn.a201 =0 then null else  nn.a201 end        as  a201 ,
       case when nn.a205 =0 then null else  nn.a205 end        as  a205 ,
       case when nn.a206  =0 then null else nn.a206 end        as  a206 ,
       case when nn.a207 =0 then null else   nn.a207 end       as  a207 ,
       case when nn.a208  =0 then null else  nn.a208 end       as  a208 ,
       case when nn.a210  =0 then null else   nn.a210 end      as  a210 ,
       case when nn.a211 =0 then null else   nn.a211 end       as  a211 ,
       case when nn.a212 =0 then null else   nn.a212 end        as  a212 ,
       case when nn.a214  =0 then null else  nn.a214 end        as  a214 ,
       case when nn.a215  =0 then null else  nn.a215 end        as  a215 ,
       case when nn.a216  =0 then null else  nn.a216 end        as  a216 ,
       case when nn.a217   =0 then null else  nn.a217 end       as  a217 ,
       case when nn.a220   =0 then null else  nn.a220 end       as  a220 ,
       case when nn.a221   =0 then null else  nn.a221 end       as  a221 ,
       case when nn.a222   =0 then null else  nn.a222 end        as  a222 ,
       case when nn.a224   =0 then null else  nn.a224 end       as  a224 ,
       case when nn.a229   =0 then null else  nn.a229 end        as  a229
  from (SELECT *
          FROM task_v_r1_reporttotal2021
        UNION ALL
        SELECT * FROM task_v_r1_reporttotal2020) nn
  order by nn.taskadmdivcode,nn.year
/

