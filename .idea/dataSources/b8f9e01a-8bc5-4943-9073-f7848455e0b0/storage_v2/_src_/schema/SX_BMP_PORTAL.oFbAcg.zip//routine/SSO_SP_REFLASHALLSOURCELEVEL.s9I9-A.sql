create procedure sso_sp_reflashAllsourcelevel(v_tablename varchar2,
                                                         v_syscode   varchar2,
                                                         v_busitype  varchar2,
                                                         v_SuperID   varchar2) as
  v_count    number;
  v_sql      varchar2(4000);
  v_sourceid varchar2(100);

  type cur is ref cursor;
  cursors cur;
begin
  sso_sp_reflashsourcelevel(v_tablename, v_syscode, v_busitype, v_SuperID);
  v_count := 0;
  v_sql   := 'select count(1) from ' || v_tablename ||
             ' t where superid = ''' || v_superid || ''' and syscode =''' ||
             v_syscode || '''  and busitype =''' || v_busitype ||
             ''' and exists (select 1 from ' || v_tablename ||
             ' a where t.sourceid = a.superid and syscode =''' || v_syscode ||
             '''  and busitype =''' || v_busitype || ''')';
  execute immediate v_sql
    into v_count;
  if v_count > 0 then
    v_sql := 'select sourceid from ' || v_tablename ||
             ' t where superid = ''' || v_superid || ''' and syscode =''' ||
             v_syscode || '''  and busitype =''' || v_busitype ||
             ''' and exists (select 1 from ' || v_tablename ||
             ' a where t.sourceid = a.superid and syscode =''' || v_syscode ||
             '''  and busitype =''' || v_busitype || ''')';
    open cursors for v_sql;
    loop
      fetch cursors
        into v_sourceid;
      exit when cursors%notfound;
      sso_sp_reflashAllsourcelevel(v_tablename,
                                v_syscode,
                                v_busitype,
                                v_sourceid);
    end loop;
    close cursors;
  end if;
end sso_sp_reflashAllsourcelevel;

/

