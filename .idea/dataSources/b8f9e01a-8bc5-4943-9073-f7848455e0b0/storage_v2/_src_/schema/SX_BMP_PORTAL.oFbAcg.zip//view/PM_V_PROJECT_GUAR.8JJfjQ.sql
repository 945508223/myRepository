create view PM_V_PROJECT_GUAR as
SELECT "PRO_ID",
       "PRO_CODE",
       "PRO_NAME",
       "PRO_CAT_CODE",
       "AGENCY_CODE",
       "MOF_DEP_CODE",
       "DEPT_CODE",
       "TRAOBJ_AGENCY_CODE",
       "CEN_TRA_PRO_CODE",
       "PRO_SOURCE_CODE",
       "PRO_DESC",
       "EXP_FUNC_CODE",
       "GUID",
       "MOF_DIV_CODE",
       "YEAR",
       "PRO_TRA_STATUS",
       PRO_TOTAL_AMT as APPLY_UP
  FROM pm_project_info@ifmis
  where PRO_CAT_CODE='2'
/

