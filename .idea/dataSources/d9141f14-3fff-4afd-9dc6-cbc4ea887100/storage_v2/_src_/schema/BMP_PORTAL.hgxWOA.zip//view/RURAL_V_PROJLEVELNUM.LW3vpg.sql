create view RURAL_V_PROJLEVELNUM as
with fw_admindiv as(
select n.year,n.GUID,n.ITEMCODE ,n.ITEMNAME,n.ENDFLAG,n.SUPERGUID from fw_t_admindiv n
),

proj_level as (
select m.year,m.SUPERGUID as admdiv ,grouping_id(m.year,
                   m.superguid
                   ) groupid,
           --??????
       nvl(sum(m.agencynum), 0) as agencynum,
       --??????
       nvl(sum(m.projnum), 0) as projnum,
       --????????
       nvl(sum(m.projpipeinum), 0) as projpipeinum,
       --????????
       nvl(sum(m.xjbm_projnum), 0) as xjbm_projnum,
       --???????????
       nvl(sum(m.xjcz_projnum), 0) as xjcz_projnum,
       --??????????
       nvl(sum(m.sjcz_projnum), 0) as sjcz_projnum,
       --????????
       nvl(sum(m.gjbm_projnum), 0) as gjbm_projnum,
       --??????????
       nvl(sum(m.gjxczx_projnum), 0) as gjxczx_projnum,
       --??????????
       nvl(sum(m.gjcz_projnum), 0) as gjcz_projnum
  from rural_v_projadmdivnum  m
 group by rollup(m.year,m.superguid)
)

select mm.year,
       mm.admdiv,
       fw.itemcode as admdiv_code,
       fw.itemname as admdiv_name,
       fw.SUPERGUID,
       fw.endflag,
       mm.groupid,
       --??????
       nvl(mm.agencynum, 0) as agencynum,
       --??????
       nvl(mm.projnum, 0) as projnum,
       --????????
       nvl(mm.projpipeinum, 0) as projpipeinum,
       --????????
       nvl(mm.xjbm_projnum, 0) as xjbm_projnum,
       --???????????
       nvl(mm.xjcz_projnum, 0) as xjcz_projnum,
       --??????????
       nvl(mm.sjcz_projnum, 0) as sjcz_projnum,
       --????????
       nvl(mm.gjbm_projnum, 0) as gjbm_projnum,
       --??????????
       nvl(mm.gjxczx_projnum, 0) as gjxczx_projnum,
       --??????????
       nvl(mm.gjcz_projnum, 0) as gjcz_projnum
  from fw_admindiv fw
  right join proj_level mm
    on fw.year = mm.year
   and fw.guid = mm.admdiv
/

