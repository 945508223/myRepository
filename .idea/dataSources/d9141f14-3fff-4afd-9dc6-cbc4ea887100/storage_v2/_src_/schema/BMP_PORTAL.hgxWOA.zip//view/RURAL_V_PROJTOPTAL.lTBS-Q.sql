create view RURAL_V_PROJTOPTAL as
select nn.year,
       nn.pro_top,
      (SELECT ITEMCODE FROM ELE_INDUSCLASS WHERE GUID = nn.PRO_TOP) AS PROJTYPECODE,
       (SELECT ITEMNAME FROM ELE_INDUSCLASS WHERE GUID = nn.PRO_TOP) AS PROJTYPENAME,
       (select guid from fw_t_admindiv where itemcode = nn.mof_div_code and year=nn.year) as admdiv,
       nn.mof_div_code,
       round(nvl(nn.PROJMOUNT/10000 ,0.00),2)  as PROJMOUNT,
       budget_level
  from (
        --????
        select  a.year,
                a.PRO_TOP,
                a.mof_div_code,
                SUM(a.PROJMOUNT) AS PROJMOUNT,
                '4' as budget_level
          from RURAL_PROJECT_INFO a
          where length(a.mof_div_code)= 6
         GROUP BY a.year, a.PRO_TOP, a.mof_div_code
        union all
        --????,admdiv?????id
        select a.year,
               a.PRO_TOP,
               substr(a.mof_div_code, 1, 4) as admdivcode,
               SUM(a.PROJMOUNT) AS PROJMOUNT,
               '3' as budget_level
          from RURAL_PROJECT_INFO a
          where length(a.mof_div_code)>= 4
         GROUP BY a.year, a.PRO_TOP, substr(a.mof_div_code, 1, 4)
        union all
        --????,admdiv?????id
        select a.year,
               a.PRO_TOP,
               substr(a.mof_div_code, 1, 2) as admdivcode,
               SUM(a.PROJMOUNT) AS PROJMOUNT,
               '2' as budget_level
          from RURAL_PROJECT_INFO a
            where length(a.mof_div_code)>= 2
         GROUP BY a.year, a.PRO_TOP, substr(a.mof_div_code, 1, 2)) nn
/

