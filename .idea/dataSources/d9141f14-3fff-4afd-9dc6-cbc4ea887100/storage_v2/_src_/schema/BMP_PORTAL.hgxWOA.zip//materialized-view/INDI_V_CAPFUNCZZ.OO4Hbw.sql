create materialized view INDI_V_CAPFUNCZZ
    refresh complete on demand
as
select "YEAR",
       "ADMDIV",
       "ADMDIV_CODE",
       "ADMDIV_NAME",
       "AMOUNT1_ZY",
       "AMOUNT1_GJ",
       "AMOUNT1_SJ",
       "AMOUNT1_XJ",
       "AMOUNT2_ZY",
       "AMOUNT2_GJ",
       "AMOUNT2_SJ",
       "AMOUNT2_XJ",
       "AMOUNT3_ZY",
       "AMOUNT3_GJ",
       "AMOUNT3_SJ",
       "AMOUNT3_XJ",
       "AMOUNT4_ZY",
       "AMOUNT4_GJ",
       "AMOUNT4_SJ",
       "AMOUNT4_XJ",
       "AMOUNT5_ZY",
       "AMOUNT5_GJ",
       "AMOUNT5_SJ",
       "AMOUNT5_XJ",
       "AMOUNT6_ZY",
       "AMOUNT6_GJ",
       "AMOUNT6_SJ",
       "AMOUNT6_XJ",
       "AMOUNT7_ZY",
       "AMOUNT7_GJ",
       "AMOUNT7_SJ",
       "AMOUNT7_XJ",
       "AMOUNT8_ZY",
       "AMOUNT8_GJ",
       "AMOUNT8_SJ",
       "AMOUNT8_XJ",
       "AMOUNT9_ZY",
       "AMOUNT9_GJ",
       "AMOUNT9_SJ",
       "AMOUNT9_XJ",
       "AMOUNT10_ZY",
       "AMOUNT10_GJ",
       "AMOUNT10_SJ",
       "AMOUNT10_XJ"
  from (select year,
               admdiv,
               admdiv_code,
               admdiv_name,
               projtypecode,
               zy_amount,
               gj_amount,
               sj_amount,
               xj_amount
          from rural_v_inditalamtzz) pivot(sum(nvl(zy_amount, 0)) as zy, sum(nvl(gj_amount, 0)) as gj, sum(nvl(sj_amount, 0)) as sj, sum(nvl(xj_amount, 0)) as xj for projtypecode in('001' as
                                                                                                                                                                             amount1,
                                                                                                                                                                             '002' as
                                                                                                                                                                             amount2,
                                                                                                                                                                             '003' as
                                                                                                                                                                             amount3,
                                                                                                                                                                             '004' as
                                                                                                                                                                             amount4,
                                                                                                                                                                             '005' as
                                                                                                                                                                             amount5,
                                                                                                                                                                             '006' as
                                                                                                                                                                             amount6,
                                                                                                                                                                             '007' as
                                                                                                                                                                             amount7,
                                                                                                                                                                             '008' as
                                                                                                                                                                             amount8,
                                                                                                                                                                             '009' as
                                                                                                                                                                             amount9,
                                                                                                                                                                             '010' as
                                                                                                                                                                             amount10))

/

