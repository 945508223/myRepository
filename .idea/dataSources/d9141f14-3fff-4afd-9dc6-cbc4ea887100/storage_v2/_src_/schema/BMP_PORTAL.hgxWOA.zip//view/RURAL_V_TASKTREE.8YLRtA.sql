create view RURAL_V_TASKTREE as
select m.guid as guid,
       '#' as superguid,
       m.TASKNO,
       m.TASKMONTH,
       m.TASKTYPE,
       m.ADMDIV,
       m.mof_div_code as admdivcode,
       m.mof_div_name as ADMDIVNAME,
       m.STARTDATE,
       m.ENDDATE,
       m.SUPERTASKID,
       m.guid as TASKID,
       m.TASKNAME,
       m.TASKADMDIV,
       m.TASKADMDIVCODE,
       m.TASKADMDIVNAME,
       m.TASKNAME as taskshowname,
       '#' as superadmdiv,
       '0' as endflag,
       '1' as ismast, --??????1--? 0 --?
        m.budgetlevel,
       m.TASKSTATUS,
       m.TASKUPDATE,
       m.TASKDOWNDATE,
       m.year
  from rural_task_info  m
  where m.taskstatus <> '0'
union all
select n.SUPERTASKID||TASKADMDIV  as guid,
       case when  superadmdiv ='#' then n.SUPERTASKID  else n.SUPERTASKID||superadmdiv  end as superguid,
       n.TASKNO,
       n.TASKMONTH,
       n.TASKTYPE,
       n.ADMDIV,
       n.ADMDIVCODE,
       n.ADMDIVNAME,
       N.STARTDATE,
       N.ENDDATE,
       n.SUPERTASKID,
       n.TASKID,
       n.TASKNAME,
       n.TASKADMDIV,
       n.TASKADMDIVCODE,
       n.TASKADMDIVNAME,
       n.TASKADMDIVNAME  as taskshowname,
       n.superadmdiv ,
       n.endflag,
       '0' as ismast, --?????
       n.budgetlevel,
       n.TASKSTATUS,
       n.TASKUPDATE,
       N.TASKDOWNDATE,
       n.year
  from RURAL_V_TASKDETAIL n
  where n.taskstatus <> '0'
/

