create materialized view FW_T_ADMINDIV1
    refresh force on demand
as
select "ENDFLAG","ITEMCODE","ITEMNAME","SUPERGUID","LEVELS","ORDERNUM","GUID","ISDEFAULT","STATUS","YEAR","FINADMLEVELCODE" from fw_t_admindiv@portal

/

