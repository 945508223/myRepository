create view SSO_V_CAUSER as
select "GUID",
       "CODE",
       "NAME",
       "ADMDIV",
       "AGENCY",
       "LOGPASSWORD",
       "DIVISION",
       "USERTYPE",
       "ISDATAADMIN",
       "STATUS",
       "ADMDIVCODE",
       "UPAGENCYID",
       "UPADMDIV",
       "ADMDIVLEVEL",
       "ADMDIVNAME",
       "AGENCYNAME",
       "DIVISIONNAME",
       "TELNO",
       "WECHATNO",
       remark
  from SSO_V_CAUSER@PORTAL
/

