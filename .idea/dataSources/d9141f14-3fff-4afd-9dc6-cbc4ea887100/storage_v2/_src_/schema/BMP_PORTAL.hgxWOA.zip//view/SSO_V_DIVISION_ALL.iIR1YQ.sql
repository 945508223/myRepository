create view SSO_V_DIVISION_ALL as
SELECT  GUID,
        GUID AS DIVID,
       ITEMCODE,
       ITEMNAME,
       '['||ITEMCODE||']'||ITEMNAME AS SHOWNAME,
       EndFlag,
       SUPERGUID,
       year,
       ADMDIV,
       levels,
       ordernum,
       isadmdiv --??????
    FROM SSO_V_ADMDIVAGENCY
/

