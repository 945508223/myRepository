create view RURAL_V_TASKDETAIL as
select n.TASKNO,
       n.TASKMONTH,
       n.TASKTYPE,
       n.ADMDIV,
       n.year,
       n.ADMDIVCODE,
       n.ADMDIVNAME,
       N.STARTDATE,
       N.ENDDATE,
       n.SUPERTASKID,
       n.TASKID,
       n.TASKNAME,
       n.TASKSHOWNAME,
       n.TASKADMDIV,
       n.TASKADMDIVCODE,
       n.TASKADMDIVNAME,
       t.superguid      as superadmdiv,
       t.endflag        as endflag,
       t.FINADMLEVELCODE as budgetlevel,
       n.TASKSTATUS,
       n.TASKUPDATE, --????
       N.TASKDOWNDATE,
       n.CHECKSTATUS,
       n.SUBUSER,      --???
       n.SUBDEPTMANAGER,    --?????
       n.SUBMANAGER,   --?????
       n.SUBADMDIVNAME,  --????
       n.SUBDEPARTMENT   --????
  from (SELECT B.TASKNO,
               A.TASKMONTH,
               A.TASKTYPE,
               A.ADMDIV,
               A.MOF_DIV_CODE AS ADMDIVCODE,
               A.MOF_DIV_NAME AS ADMDIVNAME,
               A.STARTDATE,
               A.ENDDATE,
               a.year,
               B.SUPERTASKID,
               B.GUID AS TASKID,
               A.TASKNAME,
               A.TASKNAME || '[' || nvl((select itemname
                                          from dm_base_codes
                                         where basetype = 'TASKSTATUS'
                                           and itemcode = B.TASKSTATUS),
                                        '???') || ']' AS TASKSHOWNAME,
               B.TASKADMDIV,
               B.TASKADMDIVCODE,
               B.TASKADMDIVNAME,
               B.TASKSTATUS,
               B.TASKUPDATE,
               B.TASKDOWNDATE,
               B.CHECKSTATUS,
               B.SUBUSER,      --???
               B.SUBDEPTMANAGER,    --?????
               B.SUBMANAGER,   --?????
               B.SUBADMDIVNAME,  --????
               B.SUBDEPARTMENT   --????
          FROM RURAL_TASK_INFO A
         RIGHT JOIN RURAL_TASK_DETAIL B
            ON A.GUID = B.SUPERTASKID) n
  left join fw_t_admindiv t
    on n.taskadmdiv = t.GUID
    and n.year=t.year
/

