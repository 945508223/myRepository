create view RURAL_V_DEPARTSET as
select a."GUID" as agencyid,  --??id
       a."ITEMCODE",
       a."ITEMNAME",
       a."SUPERGUID",
       a."ENDFLAG",
       a."YEAR",
       a."ISLEAF",
       a."ISADMDIV",
       a."ADMDIV",
       a."STATUS",
       a."LEVELS",
       a."ORDERNUM",
       a."SHOWNAME",
       a.departtype,   --????
       a.guid,         --????id
       a.BUDGET_LEVEL,
       case when a.isleaf='1' and a.budget_level in ('2','3') then  (select superguid from fw_t_admindiv where guid=a.admdiv and year=a.year) else a.admdiv end as upadmdiv
  from SSO_V_ADMDIVAGENCY a    --?????
/

