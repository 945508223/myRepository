create view SSO_V_USERROLE as
(
select m."GUID",m."CODE",m."NAME",m."ADMDIV",m."AGENCY",m."LOGPASSWORD",m."DIVISION",m."USERTYPE",m."ISDATAADMIN",m."STATUS",m."ADMDIVCODE",m."UPAGENCYID",m."UPADMDIV",m."ADMDIVLEVEL",m."ADMDIVNAME",m."AGENCYNAME",m."DIVISIONNAME",m."TELNO",m."WECHATNO",n.rolecode,n.rolename,m.remark from sso_v_causer m
 left join (
select a.USERGUID,b.itemname as rolename,b.itemcode as rolecode from sso_v_causerrole a
left join  sso_v_roleinfo b
on a.ROLEGUID =b.guid ) n
on m.GUID = n.USERGUID )
/

