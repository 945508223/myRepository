create view RURAL_V_INDIDETAILTAL as
with indi_detail as
(
select m.indi_id,
       m.year,
       m.admdiv,
       m.mof_div_code,
       m.cor_bgt_doc_no,
       m.bgt_doc_title,
       m.doc_date,
       m.budget_level_code,
       m.PROTYPE_ID,
       m.indi_detailid,
       m.dis_agency,
       (select itemcode from fw_t_admindiv where  guid = m.dis_agency and year=m.year)  as dis_agency_code,
       (select itemname from fw_t_admindiv where  guid = m.dis_agency and year=m.year)  as dis_agency_name,
       (select case  when FINADMLEVELCODE in ('2', '3') then  superguid  else  guid  end   from fw_t_admindiv   where guid = m.admdiv and year=m.year) as dis_agencyshow,
       m.amount as indi_amount,
       m.dis_amount,
       m.USE_AMOUNT,
       m.REST_AMOUNT
  from RURAL_V_INDIDETAIL m
 )

 --???????,???????
select indi_id as guid,
       indi_id,
       indi_id as indi_detailid,
       year,
       admdiv,
       mof_div_code,
       cor_bgt_doc_no,
       bgt_doc_title,
       doc_date,
       budget_level_code,
       PROTYPE_ID,
       '#' as superguid,
       admdiv as dis_agency,
       (select itemcode from fw_t_admindiv where  guid = indi_detail.dis_agencyshow and year=indi_detail.year)  as dis_agencyshow_code,
       (select itemname from fw_t_admindiv where  guid = indi_detail.dis_agencyshow and year=indi_detail.year)  as dis_agencyshow_name,
       '0' as endflag,
       '1' as levels,
       --????????
      -- case when (nvl(sum(dis_amount),0)) =0 then  round(max(indi_amount)/10000,2) else  (round(nvl(sum(dis_amount),0) /10000,2))   end  as indi_amount,
       round(max(indi_amount)/10000,2)    as indi_amount,
       round(nvl( sum(USE_AMOUNT),0)/10000,2) as use_amount,  --??????
       --??????
       --case when (nvl(sum(dis_amount),0))=0 then  round(nvl((max(indi_amount) - sum(USE_AMOUNT)),0)/10000,2) else  round(nvl((sum(dis_amount) - sum(USE_AMOUNT)),0)/10000,2)    end    as REST_AMOUNT
       round(nvl((max(indi_amount) - sum(USE_AMOUNT)),0)/10000,2)  as REST_AMOUNT
  from indi_detail
 group by indi_id,
          year,
          admdiv,
          mof_div_code,
          cor_bgt_doc_no,
          bgt_doc_title,
          doc_date,
          budget_level_code,
          PROTYPE_ID,
          dis_agencyshow
union all
--?????????????????????????
select 'G'||indi_id||substr(dis_agency_code,1,4)  as guid,
       indi_id,
       indi_id as indi_detailid,
       year,
       admdiv,
       mof_div_code,
       cor_bgt_doc_no,
       bgt_doc_title,
       doc_date,
       budget_level_code,
       PROTYPE_ID,
       indi_id as superguid,
       (select guid  from fw_t_admindiv where itemcode= substr(indi_detail.dis_agency_code,1,4) and year= indi_detail.year) as dis_agency,
       substr(dis_agency_code,1,4) as dis_agency_code,
       (select itemname from fw_t_admindiv where itemcode= substr(indi_detail.dis_agency_code,1,4) and year=indi_detail.year ) as dis_agency_name,
        '0' as endflag,
        '2' as levels,
       round(nvl(sum(dis_amount),0) /10000,2) as indi_amount,
       round(nvl( sum(USE_AMOUNT),0)/10000,2) as use_amount,
       round(nvl((sum(dis_amount) - sum(USE_AMOUNT)),0)/10000,2)  as REST_AMOUNT
  from indi_detail
  where budget_level_code in ('1','2')
 group by indi_id,
          year,
          admdiv,
          mof_div_code,
          cor_bgt_doc_no,
          bgt_doc_title,
          doc_date,
          budget_level_code,
          PROTYPE_ID,
          substr(dis_agency_code,1,4)
 union all
 --?????????????????????????????????
select indi_detailid as guid,
       indi_id,
       indi_id as indi_detailid,
       year,
       admdiv,
       mof_div_code,
       cor_bgt_doc_no,
       bgt_doc_title,
       doc_date,
       budget_level_code,
       PROTYPE_ID,
       'G'||indi_id||substr(dis_agency_code,1,4) as superguid,
       dis_agency,
       dis_agency_code,
       dis_agency_name,
       '1' as endflag,
        '3' as levels,
       round(nvl(sum(dis_amount),0) /10000,2) as indi_amount,
       round(nvl(sum(USE_AMOUNT),0)/10000,2) as use_amount,
       round(nvl((sum(dis_amount) - sum(USE_AMOUNT)),0)/10000,2)  as REST_AMOUNT
  from indi_detail
  where budget_level_code in ('1','2')
 group by indi_detailid,
          indi_id,
          year,
          admdiv,
          mof_div_code,
          cor_bgt_doc_no,
          bgt_doc_title,
          doc_date,
          budget_level_code,
          PROTYPE_ID,
          dis_agency,
          dis_agency_code,
          dis_agency_name
union all
 --?????????????????????????????????
select indi_detailid as guid,
       indi_id,
       indi_detailid,
       year,
       admdiv,
       mof_div_code,
       cor_bgt_doc_no,
       bgt_doc_title,
       doc_date,
       budget_level_code,
       PROTYPE_ID,
       indi_id as superguid,
       dis_agency,
       dis_agency_code,
       dis_agency_name,
       '1' as endflag,
        '2' as levels,
       round(nvl(sum(dis_amount),0) /10000,2) as indi_amount,
       round(nvl(sum(USE_AMOUNT),0)/10000,2) as use_amount,
       round(nvl((sum(dis_amount) - sum(USE_AMOUNT)),0)/10000,2)  as REST_AMOUNT
  from indi_detail
  where budget_level_code in ('3')
 group by indi_detailid,
          indi_id,
          year,
          admdiv,
          mof_div_code,
          cor_bgt_doc_no,
          bgt_doc_title,
          doc_date,
          budget_level_code,
          PROTYPE_ID,
          dis_agency,
          dis_agency_code,
          dis_agency_name
/

