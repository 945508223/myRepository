create view RURAL_V_PROJECTINFO as
select nn.year,
       (SELECT ITEMCODE FROM ELE_INDUSCLASS WHERE GUID = nn.PRO_SECOND) AS PROJTYPECODE,
       (SELECT ITEMNAME FROM ELE_INDUSCLASS WHERE GUID = nn.PRO_SECOND) AS PROJTYPENAME,
       (select guid from fw_t_admindiv where itemcode = nn.mof_div_code and year=nn.year) as admdiv,
       nn.mof_div_code,
       nn.PROJMOUNT,
       budget_level
  from (
        --????
        select  a.year,
                a.PRO_SECOND,
                a.mof_div_code,
                SUM(a.PROJMOUNT) AS PROJMOUNT,
                '4' as budget_level
          from RURAL_PROJECT_INFO a
         GROUP BY a.year, a.PRO_SECOND, a.mof_div_code
        union all
        --????,admdiv?????id
        select a.year,
               a.PRO_SECOND,
               substr(a.mof_div_code, 1, 4) as admdivcode,
               SUM(a.PROJMOUNT) AS PROJMOUNT,
               '3' as budget_level
          from RURAL_PROJECT_INFO a
         GROUP BY a.year, a.PRO_SECOND, substr(a.mof_div_code, 1, 4)
        union all
        --????,admdiv?????id
        select a.year,
               a.PRO_SECOND,
               substr(a.mof_div_code, 1, 2) as admdivcode,
               SUM(a.PROJMOUNT) AS PROJMOUNT,
               '2' as budget_level
          from RURAL_PROJECT_INFO a
         GROUP BY a.year, a.PRO_SECOND, substr(a.mof_div_code, 1, 2)) nn
/

