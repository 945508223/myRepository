create materialized view TASK_V_R1_REPORTANS_XJ2022
    refresh force on demand
as
with admdiv as (
select -- b.fundlevel,b.fundcn,
        a.TASKADMDIV,a.TASKADMDIVCODE,a.TASKADMDIVNAME,a.TASKID,a.SUPERTASKID,a.endflag,a.TASKMONTH,a.year
from RURAL_V_TASKDETAIL   a  WHERE YEAR='2022'/* ,
(select  '1' as fundlevel,'??' as fundcn  from dual
union
select  '2' as fundlevel,'??' as fundcn from dual
union
select  '3' as fundlevel,'???' as fundcn from dual
union
select  '4' as fundlevel,'?????' as fundcn from dual
union
select  '5' as fundlevel,'??????' as fundcn from dual
union
select  '6' as fundlevel,'???????' as fundcn from dual   )b*/

),
--??????????1-???2-?? 3-??? 4-? 5-????6-??
--2022????????\????
 zj1 as (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.adamount) as bdys2022,sum(t.finalamount) as ysjs
 from TASK_V_R1_REPORTDATAS2022  t
 where  fundname like '01%' and  t.fundlevel in ('5','6')
 group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
),
--2021????????
 zj2 as (
select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.adamount) as bdys2021
 from TASK_V_R1_REPORTDATAS  t
 where  fundname like '01%' and  t.fundlevel in ('5','6')
 group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
),

--2022??????????
 zj5 as (
 select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.amount) as amount2022
 from TASK_V_R1_REPORTDATAS2022 t
 where   /*t.fundlevel='6' and*/ fundname like '01%'  and  t.fundlevel in ('5','6') and t.payitem is not null or t.payitem <> ''
  group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
),

--2021??????????
 zj6 as (
 select t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname,sum(t.amount) as amount2021
 from TASK_V_R1_REPORTDATAS t
 where   /*t.fundlevel='6' and*/ fundname like '01%' and  t.fundlevel in ('5','6')  and t.payitem is not null or t.payitem <> ''
  group by t.supertaskid,t.taskid,t.taskadmdivcode,t.taskadmdivname
)


select aa.year, aa.supertaskid,aa.taskid,aa.taskadmdivcode,aa.taskadmdivname,aa.endflag,aa.TASKMONTH,
--????
NVL(mm.bdys2022,0) AS bdys2022,
NVL(mm.ysjs,0) AS ysjs,
NVL(nn.bdys2021,0) AS bdys2021,
NVL(oo.amount2022,0) AS amount2022,
NVL(pp.amount2021,0) AS amount2021
from  admdiv aa
left join  zj1 mm
on   aa.supertaskid= mm.supertaskid
and  aa.taskid=mm.taskid
and  aa.taskadmdivcode=mm.taskadmdivcode
and  aa.taskadmdivname=mm.taskadmdivname
left join zj2 nn
on   aa.supertaskid= nn.supertaskid
and  aa.taskid=nn.taskid
and  aa.taskadmdivcode=nn.taskadmdivcode
and  aa.taskadmdivname=nn.taskadmdivname
left join zj5  oo
on    aa.supertaskid= oo.supertaskid
and   aa.taskid=oo.taskid
and   aa.taskadmdivcode=oo.taskadmdivcode
and   aa.taskadmdivname=oo.taskadmdivname
left join zj6  pp
on    aa.supertaskid= pp.supertaskid
and   aa.taskid=pp.taskid
and   aa.taskadmdivcode=pp.taskadmdivcode
and   aa.taskadmdivname=pp.taskadmdivname

/

