create view SSO_V_PUBADMDIV as
select "ENDFLAG","ITEMCODE","ITEMNAME","SUPERGUID","LEVELS","ORDERNUM","GUID","ISDEFAULT","STATUS","YEAR",'['||itemcode||']'||itemname as showname from FW_T_ADMINDIV
/

