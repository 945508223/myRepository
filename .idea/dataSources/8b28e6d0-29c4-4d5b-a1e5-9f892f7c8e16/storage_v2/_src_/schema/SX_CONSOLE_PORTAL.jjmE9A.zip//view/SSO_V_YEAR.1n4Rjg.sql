create view SSO_V_YEAR as
select year as guid,year ,year||'年' as yearname,isdefault,isbgt,'#' as superguid  from sso_t_year
/

