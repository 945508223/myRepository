create view SSO_V_PUBADMDIV as
select ENDFLAG,ITEMCODE,ITEMNAME,'['||ITEMCODE||']'||ITEMNAME AS SHOWNAME,SUPERGUID,LEVELS,ORDERNUM,GUID,ISDEFAULT,STATUS,YEAR,GUID AS ADMDIV  from fw_t_admindiv
union all
/*--select "FINYEAR","DISTRICTID","DISTRICTCODE","DISTRICTNAME","BREVIARY","SUPERID","LEVELID","REMARK","USEFLAG","MODIFYFLAG","ALIASNAME","BUDGETLEVEL","APPENDPROP","EXTCOL1","EXTCOL2","EXTCOL3","EXTCOL4","EXTCOL5","EXTCOL6","EXTCOL7","EXTCOL8","ENDFLAG","ITEMVER","STDCODE","EFMVER"
    from
   fbmis_portal_62.Efm_t_District;*/

select a.endflag,a.admdivcode,a.admdivname,'['||a.admdivcode||']'||a.admdivname as showname,a.superguid,case when superguid='#' then a.levels else a.levels+1 end as levels,a.ordernum,a.guid,'1' as isdefault,a.status,a.year,a.guid AS ADMDIV  from sso_t_pubadmdiv_1014  a
/

