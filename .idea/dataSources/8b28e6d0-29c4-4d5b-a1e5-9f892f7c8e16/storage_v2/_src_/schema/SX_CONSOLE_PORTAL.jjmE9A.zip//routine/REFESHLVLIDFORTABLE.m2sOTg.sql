create procedure refeshlvlidfortable(v_tablename varchar2,
                                                v_year      varchar2,
                                                v_superguid varchar2,
                                                v_orderby   varchar2) as
  v_sql         varchar2(4000);
  v_countSql    varchar2(4000);
  v_updateSql   varchar2(4000);
  v_ordernumSql varchar2(4000);

  v_endflag char(1);

  v_guid          varchar2(100);
  v_ordernum      varchar2(100);
  v_superOrdernum varchar2(100);
  v_yearWhere     varchar2(1000);
  v_orderStr      varchar2(1000);

  i_count int;
  i_i     int;

  type cur is ref cursor;
  querySql cur;

begin
  --刷新ordernum
  --获取年度条件，若没有不加
  if v_year is null or trim(v_year) = '' then
    v_yearWhere := ' ';
  else
    v_yearWhere := ' and year = ''' || v_year || '''';
  end if;
  --获取传入节点的ordernum，若是#，则设置为空
  if v_superguid = '#' then
    v_superOrdernum := '';
  else
    v_ordernumSql := 'select ordernum from ' || v_tablename ||
                     ' where guid = ''' || v_superguid || '''' ||
                     v_yearWhere;
    begin
      execute immediate v_ordernumSql
        into v_superOrdernum;
    exception
      when others then
        v_superOrdernum := '';
    end;
  end if;
  --设置排序顺序
  if v_orderby is null then
    v_orderStr := ' order by itemcode ';
  else
    v_orderStr := ' order by ' || v_orderby;
  end if;
  --设置查询下级sql
  v_sql := 'select guid  from ' || v_tablename || ' where superguid = ''' ||
           v_superguid || '''' || v_yearWhere || v_orderStr;

  i_i := 1;
  open querySql for v_sql;
  loop
    fetch querySql
      into v_guid;
    exit when querySql%notfound;
    v_countSql := 'select count(1) from ' || v_tablename ||
                  ' where superguid = ''' || v_guid || '''' || v_yearWhere;
    execute immediate v_countSql
      into i_count;
    if i_count > 0 then
      v_endflag := '0';
    else
      v_endflag := '1';
    end if;
    v_ordernum  := v_superOrdernum || lpad(i_i, 6, '0');
    v_updateSql := 'update ' || v_tablename || ' set ordernum=''' ||
                   v_ordernum || ''',endflag = ''' || v_endflag ||
                   ''' where guid=''' || v_guid || '''' || v_yearWhere;
    execute immediate v_updateSql;
    if i_count > 0 then
      refeshlvlidfortable(v_tablename, v_year, v_guid, v_orderby);
    end if;
    i_i := i_i + 1;
  end loop;
  close querySql;
end;

/

