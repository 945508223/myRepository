create view SSO_V_PUBDEPARTMENT as
select year,
       guid,
       code as itemcode,
       name as itemname,
       '['||code||']'||name as showname,
       levels,
       case
         when LEVELS = '1' then
          '#'
         else
          superguid
       end as superguid,
       endflag,
       admdiv,
       admdiv as admdivcode,
       ordernum,
      '0' as  Deptpriority,
       status
  from sso_t_pubdepartment m

  union all
  select a.year,
       a.guid,
       a.code as itemcode,
       a.name as itemname,
       '['||a.code||']'||a.name as showname,
       a.levels,
       case
         when a.LEVELS = '1' then
          '#'
         else
          a.superguid
       end as superguid,
       a.endflag,
       b.guid as admdiv,
       a.admdiv as admdivcode,
       a.ordernum,
       a.Deptpriority,
       a.status
  from sso_t_pubdepartment_1014  a
  left join sso_t_pubadmdiv_1014  b
   on  a.admdiv=b.admdivcode
   and a.year=b.year
/

