create procedure dm_sp_reflashbasecodecatlvl(v_appid   varchar2,
                                                        v_superid varchar2) as
  v_levels   varchar2(50);
  v_basetype varchar2(50);

  v_i   integer := 1;
  v_cnt integer;

  type cur is ref cursor;
  cur_type cur;

begin

  v_levels := '';
  if (v_superid <> '#') then
    select levels
      into v_levels
      from dm_base_codecat t
     where  t.basetype = v_superid;
  end if;

  open cur_type for
    select t.basetype
      from dm_base_codecat t
     where t.supertype = v_superid
     order by t.orderid;

  loop
    fetch cur_type
      into v_basetype;
    exit when cur_type%notfound;
    update dm_base_codecat t
       set t.levels = v_levels ||
                      substr('0000' || v_i, length('0000' || v_i) - 3)
     where t.basetype = v_basetype;
    v_i   := v_i + 1;
    v_cnt := 0;
    select count(1)
      into v_cnt
      from dm_base_codecat t
     where t.supertype = v_basetype;
    if v_cnt > 0 then
      dm_sp_reflashbasecodecatlvl(v_appid, v_basetype);
    end if;

  end loop;
  close cur_type;

end;

/

