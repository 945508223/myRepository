create view SSO_V_DEPARTUSER as
select guid,
       superguid,
       itemcode,
       '[' || itemcode || ']' || itemname as itemname,
       levels,
       ordernum,
       endflag,
       admdiv,
       year,
       '1' as isdepartment,
       '' AS ZW
  from sso_v_pubdepartment
 WHERE STATUS <> '2' AND ADMDIV <> '****' --新增AND ADMDIV <> '****'
 --新增  20210508
 UNION ALL
 select b.guid,
       '#' superguid,
       b.itemcode,
       '[' || b.itemcode || ']' || b.itemname as itemname,
       b.levels,
       b.ordernum,
       b.endflag,
       a.guid admdiv,
       b.year,
       '1' as isdepartment,
       '' as ZW
  from sso_v_pubdepartment b,sso_v_pubadmdiv a
 WHERE b.STATUS <> '2' AND b.ADMDIV = '****'
 UNION ALL
select guid,
       division as superguid,
       a.code as itemcode,
       a.name as itemname,
       4 as levels,
       '0' as ordernum,
       '1' as endflag,
       admdiv,
       '****' AS year,
       '0' as isdepartment,
       REMARK as ZW
  from sso_v_causer a
 where a.usertype = '1'
   and a.status <> '2'
   and exists (select guid
          from sso_v_pubdepartment B
         where b.status <> '2'
           and a.division = b.guid)
/

