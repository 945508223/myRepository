create view SSO_V_ROLEMENUINFO as
select  guid, levels , endflag , status, itemcode  , replace (itemname,'<br>','')  as itemname , superguid  , url, menuorder, remark,  APPID  , param1, param2, param3, param4, param5
from   sso_t_menuinfo
/

