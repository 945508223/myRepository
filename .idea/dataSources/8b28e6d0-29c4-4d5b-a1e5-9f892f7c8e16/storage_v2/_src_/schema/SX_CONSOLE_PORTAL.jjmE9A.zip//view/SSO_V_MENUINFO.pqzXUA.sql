create view SSO_V_MENUINFO as
select  guid, levels levelno, endflag isleaf, status,itemcode code , itemname name  , superguid  parentid, url, menuorder, remark,  APPID  , param1, param2, param3, param4, param5, SHOWINHOMEPAGE from sso_t_menuinfo
/

