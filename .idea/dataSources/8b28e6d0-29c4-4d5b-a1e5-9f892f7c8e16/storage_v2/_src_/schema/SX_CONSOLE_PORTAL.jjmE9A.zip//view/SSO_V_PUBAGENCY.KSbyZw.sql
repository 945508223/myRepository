create view SSO_V_PUBAGENCY as
select "ENDFLAG",
       "SUPERGUID",
       "LEVELS",
       "ORDERNO",
       "ORDERNUM",
       "GUID",
       "YEAR",
       "AGENCYCODE"     as itemcode,
       "AGENCYNAME"     as itemname,
       "ADMDIV",
       "STATUS",
       "ORGCODE",
       "INDCODE",
       "TEL",
       "MOB",
       "FAX",
       "ADDRESS",
       "ZIP",
       "REMARK",
       "AGENCYTYPECODE",
       "AGENCYLEVECODE",
       BGTTYPEFLAG,
       PAYTYPEFLAG,
       ISDEPARTMENT,
       departtype
  from sso_t_pubagency
/

