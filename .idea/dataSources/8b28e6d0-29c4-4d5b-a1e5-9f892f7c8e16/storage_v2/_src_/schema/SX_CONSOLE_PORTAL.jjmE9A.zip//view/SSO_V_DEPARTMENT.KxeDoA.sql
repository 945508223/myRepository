create view SSO_V_DEPARTMENT as
SELECT  GUID,
        GUID AS DIVID,
       ITEMCODE ,
       ITEMNAME ,
       '['||ITEMCODE||']'||ITEMNAME AS DIVSHOWNAME,
       EndFlag,
       case when  isadmdiv='1' and EndFlag='1' then '#' else  SUPERGUID  end as superguid,
       year,
       ADMDIV as districtid,
       levels,
       ordernum,
       isadmdiv --是否行政区划
    FROM SSO_V_ADMDIVAGENCY
    WHERE isadmdiv='0' OR (  isadmdiv='1' and EndFlag='1')
/

