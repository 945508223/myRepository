create view SSO_V_CAROLEMENU as
select   ROLEGUID,menuid as  menuguid FROM  sso_t_rolemenu
/

