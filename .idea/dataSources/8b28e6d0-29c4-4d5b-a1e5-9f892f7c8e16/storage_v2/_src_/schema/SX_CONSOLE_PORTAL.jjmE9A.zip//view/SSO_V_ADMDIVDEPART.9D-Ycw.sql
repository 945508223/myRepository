create view SSO_V_ADMDIVDEPART as
select guid,
       superguid,
       itemcode,
       itemname,
       '['||itemcode||']'||itemname as showname,
       LEVELS,
       ORDERNUM,
       '0' as endflag,
       endflag as isleaf,
       guid admdiv,
       YEAR,
       '1' as isadmdiv,
       STATUS,
       '0' is_pubDept
 from sso_v_pubadmdiv
union all
select guid,
       case when  superguid='#' then admdiv  else  superguid end as superguid  ,
       itemcode,
       itemname,
        '['||itemcode||']'||itemname as showname,
       levels,
       ordernum,
       endflag,
       endflag as isleaf,
       admdiv,
       year,
       '0' as isadmdiv,
       STATUS,
       admdiv as  is_pubDept
  from sso_v_pubdepartment where ADMDIV <>  '****'

union all
  select  b.guid,
        case when  b.superguid='#' then a.admdiv  else  b.superguid end as superguid  ,
        b.itemcode,
        b.itemname,
         '['||b.itemcode||']'||b.itemname as showname,
        b.LEVELS,
        b.ORDERNUM,
        b.endflag,
        b.endflag as isleaf,
        a.guid as admdiv,
        b.YEAR,
        '0' as isadmdiv,
        b.STATUS,
       b.admdiv as  is_pubDept
 from sso_v_pubadmdiv a,sso_v_pubdepartment b
 where a.endflag = '1' and (b.ADMDIV = '****'and  b.ADMDIV =a.GUID)
/

