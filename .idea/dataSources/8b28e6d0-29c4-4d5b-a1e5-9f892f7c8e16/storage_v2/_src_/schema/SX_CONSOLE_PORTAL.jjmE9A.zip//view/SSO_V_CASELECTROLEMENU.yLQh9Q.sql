create view SSO_V_CASELECTROLEMENU as
select  b.guid,a.roleguid,a.menuid,b.itemcode,REPLACE(b.itemname, '<br>','') itemname,b.superguid,b.endflag,b.status,b.appid,b.menuorder
  from sso_t_rolemenu a
  right join sso_t_menuinfo b
    on a.menuid = b.guid
    where b.status='1'
/

