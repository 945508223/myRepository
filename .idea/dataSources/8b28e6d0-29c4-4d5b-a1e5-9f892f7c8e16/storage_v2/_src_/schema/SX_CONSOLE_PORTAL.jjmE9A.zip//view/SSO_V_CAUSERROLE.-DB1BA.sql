create view SSO_V_CAUSERROLE as
select  t.userguid,b.code,b.name,b.admdiv,b.agencyid,t.roleguid,c.rolecode,c.rolename
 from sso_t_userrole t
left join  sso_t_userinfo b
on t.userguid=b.guid
left join sso_t_roleinfo c
on t.roleguid = c.guid
/

