create view SSO_V_ADMDIVDEPARTUSER as
select guid,
       superguid,
       itemcode,
       '[' || itemcode || ']' || itemname as itemname,
       LEVELS,
       ORDERNUM,
       endflag,
       guid admdiv,
       YEAR
  from sso_v_pubadmdiv
union all
select guid,
       (case superguid
         when '#' then
          admdiv
         else
          superguid
       end) as superguid,
       itemcode,
       itemname,
       levels,
       ordernum,
       endflag,
       admdiv,
       year
  from sso_v_pubdepartment
  union all
  select guid,
       division  as superguid,
       code as itemcode,
       name as itemname,
       0 levels,
       '' ordernum,
       '1' endflag,
       admdiv,
       '' year
  from sso_v_causer
  where usertype in ('1','-1')
/

