create view SSO_V_DIVISION as
SELECT GUID,
       YEAR,
       ITEMCODE,
       ITEMNAME,
       SUPERGUID,
       LEVELS,
       ORDERNUM,
       STATUS,
       '0' ENDFLAG
FROM sso_v_pubadmdiv
UNION ALL
SELECT GUID,
       YEAR,
       ITEMCODE,
       ITEMNAME,
       SUPERGUID,
       LEVELS,
       ORDERNUM,
       STATUS,
       ENDFLAG
FROM Sso_v_Pubagency
/

