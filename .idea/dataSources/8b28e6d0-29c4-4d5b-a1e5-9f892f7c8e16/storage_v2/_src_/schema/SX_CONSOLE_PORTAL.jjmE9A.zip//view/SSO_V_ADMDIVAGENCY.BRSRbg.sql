create view SSO_V_ADMDIVAGENCY as
select guid,
       itemcode,
       itemname,
       superguid,
       endflag,
       year,
       isleaf,
       isadmdiv,
       admdiv,
       status,
       LEVELS,
       ordernum,
       '[' || itemcode || ']' || itemname as showname,
       budget_level,
       departtype
  from (select guid,
               itemcode,
               itemname,
               superguid,
               '0' as endflag,
               year,
               endflag as isleaf,
               '1' as isadmdiv,
               guid as admdiv,
               '1' as status,
               0 LEVELS,
               ordernum,
               finadmlevelcode as budget_level,
                '' as departtype
          from fw_t_admindiv
        --新增加公共部门 Date:20210508
        union all
        --公共部门
        select b.guid guid,
               b.itemcode,
               b.itemname,
               a.GUID as superguid,
               b.endflag,
               b.year,
               b.endflag as isleaf,
               '0' as isadmdiv,
               a.guid admdiv,
               b.STATUS,
               b.LEVELS,
               b.ordernum,
               a.finadmlevelcode as budget_level,
               b.departtype
          from sso_v_pubagency b, fw_t_admindiv a
         where (b.ADMDIV = '****' or b.ADMDIV = a.GUID)
           and b.ADMDIV = '****'
           and a.endflag = 1
        --单位表
        union all
        select b.guid,
               b.itemcode,
               b.itemname,
               b.superguid,
               b.endflag,
               b.year,
               b.endflag as isleaf,
               '0' as isadmdiv,
               b.admdiv,
               b.STATUS,
               b.LEVELS,
               b.ordernum,
               a.finadmlevelcode as budget_level,
               b.departtype
           from sso_v_pubagency b, fw_t_admindiv a
         where ADMDIV <> '****'
         and b.ADMDIV=a.guid
         and b.year=a.year)
/

