create view SSO_V_DEPARTDIVISION as
select  GUID,
        DIVID,
        ITEMCODE,
        ITEMNAME,
        DIVSHOWNAME,
        ENDFLAG,
        SUPERGUID,
        YEAR,
        DISTRICTID,
        LEVELS,
        ORDERNUM,
        ISADMDIV
  from SSO_V_DEPARTMENT a
 where LEVELS IN ('0','1')
/

