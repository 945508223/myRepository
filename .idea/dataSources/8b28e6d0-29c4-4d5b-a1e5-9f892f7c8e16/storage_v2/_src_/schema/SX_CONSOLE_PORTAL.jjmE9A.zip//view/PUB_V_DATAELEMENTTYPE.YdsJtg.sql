create view PUB_V_DATAELEMENTTYPE as
select a.guid,
       a.year,
       a.itemcode as code,
       a.itemname as name,
       a.status,
       '#' as superguid,
       '1' as endflag，
       1 as levels,
       '1' as ORDERNUM
  from PUB_T_DATAELEMENTTYPE a
/

