create view SSO_V_CAUSER as
SELECT  a.guid,
        a.code,
        a.name,
        a.admdiv,
        a.agencyid as agency,
        a.password as LogPassWord,
        a.division,
        a.UserType,
        a.isdataadmin,
        a.status,
        a.province as admdivcode,
        case when a.UserType=1  and substr(a.province,length(a.province)-1,2) ='00' then  ( select  superguid  from fw_t_admindiv where  guid= a.admdiv and rownum=1)
           else  a.upagencyid
             end  as upagencyid ,
        case when   upadmdiv is not null or upadmdiv <> '' then  upadmdiv
          when  substr(a.province,length(a.province)-1,2) ='00' and ( upadmdiv is null or upadmdiv='' ) then  ( select  superguid  from fw_t_admindiv where  guid= a.admdiv and rownum=1)
           else  a.admdiv
             end  as upadmdiv ,
        ( select  finadmlevelcode  from fw_t_admindiv where  guid= a.admdiv and rownum=1) as admdivlevel,
        (select itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivname,
        (select '['||itemcode||']'||itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivshowname,
        (select itemname  from sso_v_admdivagency where guid=a.agencyid and rownum=1) as agencyname,
        (select '['||itemcode||']'||itemname  from sso_v_admdivagency where guid=a.agencyid and rownum=1) as agencyshowname,
        (select '['||itemcode||']'||itemname  from sso_v_pubdepartment where guid=a.division and rownum=1) as divisionname,
        a.telno,
        a.wechatno,
        a.remark
  FROM  sso_t_userinfo a
/

