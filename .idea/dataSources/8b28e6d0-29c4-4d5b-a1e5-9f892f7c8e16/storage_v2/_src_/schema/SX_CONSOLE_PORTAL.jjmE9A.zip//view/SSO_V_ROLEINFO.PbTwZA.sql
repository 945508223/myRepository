create view SSO_V_ROLEINFO as
select "GUID",
       "ROLECODE" as itemcode,
       "ROLENAME" as itemname,
       "ADMDIV",
       "AGENCY",
       "ROLETYPE",
       "STATUS",
        "ISSYS",
       "REMARK",
       "PROVINCE",
       --"ROLENATURE",
       '#' as superguid,
        (select '['||itemcode||']'||itemname from sso_v_pubadmdiv where guid=a.admdiv and rownum=1) as admdivname,
        (select '['||itemcode||']'||itemname  from sso_v_pubagency where guid=a.agency and rownum=1) as agencyname,
        A.is_pubrole
  from sso_t_roleinfo a
/

