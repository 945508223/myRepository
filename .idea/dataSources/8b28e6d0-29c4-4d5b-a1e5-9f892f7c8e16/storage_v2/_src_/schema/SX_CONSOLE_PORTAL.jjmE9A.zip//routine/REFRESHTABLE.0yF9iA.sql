create procedure refreshtable(v_tableName  varchar2) AS
  v_sql           varchar2(4000);
  v_sql2  varchar2(4000);
  v_sql3  varchar2(4000);
  v_guid varchar2(32);
  v_code  varchar2(100);
  v_ordernum varchar2(100);
  v_i number;
  v_count number;
  type cur IS ref CURSOR;
  v_query cur;
BEGIN

  v_i := 0;
  v_sql := 'select guid,itemcode  from ' || v_tablename || ' where superguid = ''#'' order by itemcode ' ;
  
  OPEN v_query FOR  v_sql;
  LOOP
    FETCH v_query
      INTO v_guid,v_code;
    EXIT WHEN v_query % notfound;
    v_i        := v_i + 1;
    v_ordernum :=  lpad(v_i, 6, '0');
    v_count    := 0;
    v_sql2 :=' SELECT count(1)    FROM '|| v_tableName||'   WHERE superguid = '''||v_guid||'''';
    execute immediate v_sql2 into v_count;
    IF v_count > 0 THEN
       v_sql3 :=' UPDATE '||v_tableName||'  SET ordernum = '''||v_ordernum||''', endflag = ''0'',levels=''1'' WHERE guid = '''||v_guid||'''';
       execute immediate v_sql3;
       refeshlvlidfortable(v_tableName ,'2021',v_guid,null);
    ELSE
      v_sql3:=' UPDATE '||v_tableName||'  SET ordernum = '''||v_ordernum||''', endflag = ''1'',levels=''1'' WHERE guid = '''||v_guid||'''';
       execute immediate v_sql3;
    END IF;
  END LOOP;
  CLOSE v_query;
END;
/

